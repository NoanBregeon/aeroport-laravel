<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Terminal extends Model
{
    protected $fillable = [
        'nom',
        'emplacement',
        'date_mise_en_service',
    ];

    protected $casts = [
        'date_mise_en_service' => 'date',
    ];

    public function halls()
    {
        return $this->hasMany(Hall::class);
    }
}
