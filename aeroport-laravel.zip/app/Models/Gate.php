<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Gate extends Model
{
    use HasFactory;

    protected $casts = [
        'ouverte' => 'boolean',
    ];

    protected $fillable = [
        'hall_id',
        'nom',
        'ouverte',
        'capacite_max',
        'capacite',
    ];

    public function hall()
    {
        return $this->belongsTo(Hall::class);
    }
}
