<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Gate extends Model
{
    protected $fillable = [
        'hall_id',
        'nom',
        'is_open',
        'capacite_max',
    ];

    protected $casts = [
        'is_open' => 'boolean',
    ];

    public function hall()
    {
        return $this->belongsTo(Hall::class);
    }
}
