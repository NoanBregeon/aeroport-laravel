<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Hall extends Model
{
    protected $fillable = [
        'terminal_id',
        'nom',
        'min_personnel',
    ];

    public function terminal()
    {
        return $this->belongsTo(Terminal::class);
    }

    public function gates()
    {
        return $this->hasMany(Gate::class);
    }
}
