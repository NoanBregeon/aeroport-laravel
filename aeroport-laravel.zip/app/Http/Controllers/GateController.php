<?php

namespace App\Http\Controllers;

use App\Models\Gate;
use App\Models\Hall;
use Illuminate\Http\Request;

class GateController extends Controller
{
    public function index()
    {
        // Les tests s’attendent à une vue 'gates.index' avec une variable 'gates'
        $gates = Gate::with('hall.terminal')->get();

        return view('gates.index', compact('gates'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'hall_id'      => ['required', 'exists:halls,id'],
            'nom'          => ['required', 'string', 'max:255'],
            'ouverte'      => ['required', 'boolean'],
            'capacite_max' => ['required', 'integer', 'min:0'],
            'capacite'     => ['required', 'integer', 'min:0'],
        ]);

        Gate::create($validated);

        return redirect()->route('gates.index');
    }
}
