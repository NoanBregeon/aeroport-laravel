<?php

namespace App\Http\Controllers;

use App\Models\Gate;
use App\Models\Hall;
use App\Models\Terminal;
use Illuminate\Http\Request;

class OperatorController extends Controller
{
    public function dashboard()
    {
        return view('operator.dashboard', [
            'terminals' => Terminal::with('halls.gates')->get()
        ]);
    }

    public function toggleGate(Gate $gate)
    {
        $gate->is_open = !$gate->is_open;
        $gate->save();

        return back()->with('success', 'État de la porte mis à jour.');
    }

    public function updateHallPersonnel(Request $request, Hall $hall)
    {
        $request->validate([
            'min_personnel' => 'required|integer|min:0',
        ]);

        $hall->min_personnel = $request->min_personnel;
        $hall->save();

        return back()->with('success', 'Personnel minimum mis à jour.');
    }
}
