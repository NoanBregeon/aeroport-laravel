<?php

namespace App\Http\Controllers;

use App\Models\Hall;
use App\Models\Terminal;
use Illuminate\Http\Request;

class HallController extends Controller
{
    public function index()
    {
        // Les tests s’attendent à une vue 'halls.index' avec une variable 'halls'
        $halls = Hall::with('terminal')->get();

        return view('halls.index', compact('halls'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'terminal_id'        => ['required', 'exists:terminals,id'],
            'nom'                => ['required', 'string', 'max:255'],
            'personnel_minimum'  => ['required', 'integer', 'min:0'],
        ]);

        Hall::create($validated);

        // Les tests font juste $response->assertRedirect()
        // donc un redirect vers index va très bien
        return redirect()->route('halls.index');
    }
}
