<?php

namespace App\Http\Controllers;

use App\Models\Terminal;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class TerminalController extends Controller
{
    /**
     * Affiche la liste des terminaux.
     */
    public function index(): View
    {
        $terminals = Terminal::with('halls.gates')->get();

        // Doit correspondre à ce qu’attend ton test : 'terminals.index'
        return view('terminals.index', compact('terminals'));
    }

    /**
     * Enregistre un nouveau terminal.
     */
    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'code' => ['required', 'string', 'max:10'],
        ]);

        Terminal::create($validated);

        return redirect()->route('terminals.index');
    }
}
