@extends('layouts.admin')

@section('title', 'Dashboard')

@section('content')

<div class="grid grid-cols-1 md:grid-cols-3 gap-6">

    <div class="p-6 bg-white shadow-lg rounded-xl border border-gray-200">
        <h2 class="text-xl font-semibold text-gray-700">Terminaux</h2>
        <p class="text-5xl font-bold text-blue-600 mt-3">
            {{ $stats['terminaux'] }}
        </p>
    </div>

    <div class="p-6 bg-white shadow-lg rounded-xl border border-gray-200">
        <h2 class="text-xl font-semibold text-gray-700">Halls</h2>
        <p class="text-5xl font-bold text-green-600 mt-3">
            {{ $stats['halls'] }}
        </p>
    </div>

    <div class="p-6 bg-white shadow-lg rounded-xl border border-gray-200">
        <h2 class="text-xl font-semibold text-gray-700">Gates</h2>
        <p class="text-5xl font-bold text-purple-600 mt-3">
            {{ $stats['gates'] }}
        </p>
    </div>

</div>

@endsection
