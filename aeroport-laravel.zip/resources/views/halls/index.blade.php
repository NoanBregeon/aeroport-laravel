<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Halls') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">

                    <table class="table-auto w-full">
                        <thead>
                            <tr>
                                <th class="px-4 py-2">ID</th>
                                <th class="px-4 py-2">Nom</th>
                                <th class="px-4 py-2">Terminal</th>
                                <th class="px-4 py-2">Personnel minimum</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($halls as $hall)
                                <tr>
                                    <td class="border px-4 py-2">{{ $hall->id }}</td>
                                    <td class="border px-4 py-2">{{ $hall->nom }}</td>
                                    <td class="border px-4 py-2">{{ $hall->terminal->nom ?? '-' }}</td>
                                    <td class="border px-4 py-2">{{ $hall->personnel_minimum }}</td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>
</x-app-layout>
