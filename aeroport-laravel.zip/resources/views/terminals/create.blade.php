<x-app-layout>
    <div class="container mx-auto py-6">
        <h1 class="text-2xl font-bold mb-4">Nouveau terminal</h1>

        <form action="{{ route('terminals.store') }}" method="POST" class="max-w-lg">
            @csrf

            <div class="mb-4">
                <label for="nom" class="block mb-1 font-semibold">Nom</label>
                <input type="text" name="nom" id="nom"
                       value="{{ old('nom') }}"
                       class="border rounded px-3 py-2 w-full">
                @error('nom')
                    <p class="text-red-600 text-sm mt-1">{{ $message }}</p>
                @enderror
            </div>

            <div class="mb-4">
                <label for="emplacement" class="block mb-1 font-semibold">Emplacement</label>
                <input type="text" name="emplacement" id="emplacement"
                       value="{{ old('emplacement') }}"
                       class="border rounded px-3 py-2 w-full">
                @error('emplacement')
                    <p class="text-red-600 text-sm mt-1">{{ $message }}</p>
                @enderror
            </div>

            <div class="mb-4">
                <label for="date_mise_en_service" class="block mb-1 font-semibold">
                    Date de mise en service
                </label>
                <input type="date" name="date_mise_en_service" id="date_mise_en_service"
                       value="{{ old('date_mise_en_service') }}"
                       class="border rounded px-3 py-2 w-full">
                @error('date_mise_en_service')
                    <p class="text-red-600 text-sm mt-1">{{ $message }}</p>
                @enderror
            </div>

            <button type="submit"
                    class="bg-blue-600 text-white px-4 py-2 rounded">
                Créer
            </button>
        </form>
    </div>
</x-app-layout>
