<x-app-layout>
    <div class="container mx-auto py-6">
        <h1 class="text-2xl font-bold mb-4">
            Nouvelle porte pour le hall {{ $hall->nom }}
            (Terminal {{ $hall->terminal->nom }})
        </h1>

        <form action="{{ route('gates.store') }}" method="POST" class="max-w-lg">
            @csrf

            <input type="hidden" name="hall_id" value="{{ $hall->id }}">

            <div class="mb-4">
                <label class="block mb-1 font-semibold" for="nom">Nom</label>
                <input type="text" name="nom" id="nom"
                       value="{{ old('nom') }}"
                       class="border rounded px-3 py-2 w-full">
                @error('nom')
                    <p class="text-red-600 text-sm mt-1">{{ $message }}</p>
                @enderror
            </div>

            <div class="mb-4">
                <label class="block mb-1 font-semibold" for="capacite_max">
                    Capacité maximale
                </label>
                <input type="number" min="0" name="capacite_max" id="capacite_max"
                       value="{{ old('capacite_max') }}"
                       class="border rounded px-3 py-2 w-full">
                @error('capacite_max')
                    <p class="text-red-600 text-sm mt-1">{{ $message }}</p>
                @enderror
            </div>

            <div class="mb-4 flex items-center gap-2">
                <input type="checkbox" name="ouverte" id="ouverte"
                       value="1" {{ old('ouverte') ? 'checked' : '' }}>
                <label for="ouverte" class="font-semibold">Porte ouverte</label>
            </div>

            <button type="submit"
                    class="bg-blue-600 text-white px-4 py-2 rounded">
                Créer la porte
            </button>
        </form>

        <div class="mt-4">
            <a href="{{ route('terminals.show', $hall->terminal_id) }}"
               class="text-blue-600 underline">
                ← Retour au terminal
            </a>
        </div>
    </div>
</x-app-layout>
