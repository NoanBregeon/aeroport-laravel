<?php

use App\Http\Controllers\GateController;
use App\Http\Controllers\HallController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\TerminalController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {

    Route::get('/', [TerminalController::class, 'index'])->name('home');

    // Terminals (index, store)
    Route::resource('terminals', TerminalController::class)->only(['index', 'store']);

    // Halls (index, store)
    Route::get('/halls', [HallController::class, 'index'])->name('halls.index');
    Route::post('/halls', [HallController::class, 'store'])->name('halls.store');

    // Gates (index, store)
    Route::get('/gates', [GateController::class, 'index'])->name('gates.index');
    Route::post('/gates', [GateController::class, 'store'])->name('gates.store');

    // Admin only
    Route::middleware('role:admin')->group(function () {
        Route::get('/terminals/create', [TerminalController::class, 'create'])->name('terminals.create');
        // etc...
    });

    // Admin + operator
    Route::middleware('role:admin,operator')->group(function () {
        Route::get('/halls/{hall}/edit', [HallController::class, 'edit'])->name('halls.edit');
        // etc...
    });

    // profile routes
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

// Changer la langue de l'utilisateur connecté
Route::post('/locale', function (Request $request) {
    $data = $request->validate([
        'locale' => ['required', 'in:fr,en'],
    ]);

    $request->session()->put('locale', $data['locale']);

    if ($request->user()) {
        $request->user()->update([
            'locale' => $data['locale'],
        ]);
    }

    return back();
})->name('locale.update');

require __DIR__.'/auth.php';
