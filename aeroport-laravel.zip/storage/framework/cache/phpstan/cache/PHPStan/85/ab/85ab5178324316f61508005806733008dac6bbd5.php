<?php declare(strict_types = 1);

// odsl-C:/code/aeroport-laravel/vendor/composer/../staabm/side-effects-detector/lib/
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v1',
   'data' => 
  array (
    'C:\\code\\aeroport-laravel\\vendor\\staabm\\side-effects-detector\\lib\\functionMetadata.php' => 
    array (
      0 => '1aa618dad516dc9f87bd8ef9a71e91b294af1b37',
      1 => 
      array (
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\staabm\\side-effects-detector\\lib\\SideEffect.php' => 
    array (
      0 => 'e82c420734a6cebde3936a3958834743054f3317',
      1 => 
      array (
        0 => 'staabm\\sideeffectsdetector\\sideeffect',
      ),
      2 => 
      array (
        0 => 'staabm\\sideeffectsdetector\\__construct',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\staabm\\side-effects-detector\\lib\\SideEffectsDetector.php' => 
    array (
      0 => '5310c220f3d865767580042159f29a44f831fed2',
      1 => 
      array (
        0 => 'staabm\\sideeffectsdetector\\sideeffectsdetector',
      ),
      2 => 
      array (
        0 => 'staabm\\sideeffectsdetector\\__construct',
        1 => 'staabm\\sideeffectsdetector\\getsideeffects',
        2 => 'staabm\\sideeffectsdetector\\getfunctioncallsideeffect',
        3 => 'staabm\\sideeffectsdetector\\getfunctioncall',
        4 => 'staabm\\sideeffectsdetector\\getmethodcall',
        5 => 'staabm\\sideeffectsdetector\\getpropertyaccess',
        6 => 'staabm\\sideeffectsdetector\\isanonymousfunction',
        7 => 'staabm\\sideeffectsdetector\\isnonlocalvariable',
        8 => 'staabm\\sideeffectsdetector\\consumewhitespaces',
      ),
      3 => 
      array (
      ),
    ),
  ),
));