<?php declare(strict_types = 1);

// odsl-C:/code/aeroport-laravel/vendor/composer/../cmgmyr/phploc/src/
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v1',
   'data' => 
  array (
    'C:\\code\\aeroport-laravel\\vendor\\cmgmyr\\phploc\\src\\Analyser.php' => 
    array (
      0 => '57ce59d497f40d763dbc77a24aa5bfbdc4be95a5',
      1 => 
      array (
        0 => 'cmgmyr\\phploc\\analyser',
      ),
      2 => 
      array (
        0 => 'cmgmyr\\phploc\\__construct',
        1 => 'cmgmyr\\phploc\\countfiles',
        2 => 'cmgmyr\\phploc\\preprocessfile',
        3 => 'cmgmyr\\phploc\\countfile',
        4 => 'cmgmyr\\phploc\\getnamespacename',
        5 => 'cmgmyr\\phploc\\getclassname',
        6 => 'cmgmyr\\phploc\\istestclass',
        7 => 'cmgmyr\\phploc\\istestmethod',
        8 => 'cmgmyr\\phploc\\getnextnonwhitespacetokenpos',
        9 => 'cmgmyr\\phploc\\getpreviousnonwhitespacetokenpos',
        10 => 'cmgmyr\\phploc\\getpreviousnonwhitespacenoncommenttokenpos',
        11 => 'cmgmyr\\phploc\\isclassdeclaration',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\cmgmyr\\phploc\\src\\CLI\\Application.php' => 
    array (
      0 => '9a8291abe35fd3716ca300a8d1e1d9b6dd55c03c',
      1 => 
      array (
        0 => 'cmgmyr\\phploc\\application',
      ),
      2 => 
      array (
        0 => 'cmgmyr\\phploc\\run',
        1 => 'cmgmyr\\phploc\\printversion',
        2 => 'cmgmyr\\phploc\\help',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\cmgmyr\\phploc\\src\\CLI\\Arguments.php' => 
    array (
      0 => 'c4026d0ce0f6c7f66356826fc22616068900818a',
      1 => 
      array (
        0 => 'cmgmyr\\phploc\\arguments',
      ),
      2 => 
      array (
        0 => 'cmgmyr\\phploc\\__construct',
        1 => 'cmgmyr\\phploc\\directories',
        2 => 'cmgmyr\\phploc\\suffixes',
        3 => 'cmgmyr\\phploc\\exclude',
        4 => 'cmgmyr\\phploc\\counttests',
        5 => 'cmgmyr\\phploc\\csvlogfile',
        6 => 'cmgmyr\\phploc\\jsonlogfile',
        7 => 'cmgmyr\\phploc\\xmllogfile',
        8 => 'cmgmyr\\phploc\\help',
        9 => 'cmgmyr\\phploc\\version',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\cmgmyr\\phploc\\src\\CLI\\ArgumentsBuilder.php' => 
    array (
      0 => 'abbecee638b8c3bc81bfed9fff70f360b8e6f121',
      1 => 
      array (
        0 => 'cmgmyr\\phploc\\argumentsbuilder',
      ),
      2 => 
      array (
        0 => 'cmgmyr\\phploc\\build',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\cmgmyr\\phploc\\src\\Collector.php' => 
    array (
      0 => '473937abef035f7764e2c967c18c343c9c4d180d',
      1 => 
      array (
        0 => 'cmgmyr\\phploc\\collector',
      ),
      2 => 
      array (
        0 => 'cmgmyr\\phploc\\getpublisher',
        1 => 'cmgmyr\\phploc\\addfile',
        2 => 'cmgmyr\\phploc\\incrementlines',
        3 => 'cmgmyr\\phploc\\incrementcommentlines',
        4 => 'cmgmyr\\phploc\\incrementlogicallines',
        5 => 'cmgmyr\\phploc\\currentclassreset',
        6 => 'cmgmyr\\phploc\\currentclassstop',
        7 => 'cmgmyr\\phploc\\currentclassincrementcomplexity',
        8 => 'cmgmyr\\phploc\\currentclassincrementlines',
        9 => 'cmgmyr\\phploc\\currentmethodstart',
        10 => 'cmgmyr\\phploc\\currentclassincrementmethods',
        11 => 'cmgmyr\\phploc\\currentmethodincrementcomplexity',
        12 => 'cmgmyr\\phploc\\currentmethodincrementlines',
        13 => 'cmgmyr\\phploc\\currentmethodstop',
        14 => 'cmgmyr\\phploc\\incrementfunctionlines',
        15 => 'cmgmyr\\phploc\\incrementcomplexity',
        16 => 'cmgmyr\\phploc\\addpossibleconstantaccesses',
        17 => 'cmgmyr\\phploc\\addconstant',
        18 => 'cmgmyr\\phploc\\incrementglobalvariableaccesses',
        19 => 'cmgmyr\\phploc\\incrementsuperglobalvariableaccesses',
        20 => 'cmgmyr\\phploc\\incrementnonstaticattributeaccesses',
        21 => 'cmgmyr\\phploc\\incrementstaticattributeaccesses',
        22 => 'cmgmyr\\phploc\\incrementnonstaticmethodcalls',
        23 => 'cmgmyr\\phploc\\incrementstaticmethodcalls',
        24 => 'cmgmyr\\phploc\\addnamespace',
        25 => 'cmgmyr\\phploc\\incrementinterfaces',
        26 => 'cmgmyr\\phploc\\incrementtraits',
        27 => 'cmgmyr\\phploc\\incrementabstractclasses',
        28 => 'cmgmyr\\phploc\\incrementnonfinalclasses',
        29 => 'cmgmyr\\phploc\\incrementfinalclasses',
        30 => 'cmgmyr\\phploc\\incrementnonstaticmethods',
        31 => 'cmgmyr\\phploc\\incrementstaticmethods',
        32 => 'cmgmyr\\phploc\\incrementpublicmethods',
        33 => 'cmgmyr\\phploc\\incrementprotectedmethods',
        34 => 'cmgmyr\\phploc\\incrementprivatemethods',
        35 => 'cmgmyr\\phploc\\incrementnamedfunctions',
        36 => 'cmgmyr\\phploc\\incrementanonymousfunctions',
        37 => 'cmgmyr\\phploc\\incrementglobalconstants',
        38 => 'cmgmyr\\phploc\\incrementpublicclassconstants',
        39 => 'cmgmyr\\phploc\\incrementnonpublicclassconstants',
        40 => 'cmgmyr\\phploc\\incrementtestclasses',
        41 => 'cmgmyr\\phploc\\incrementtestmethods',
        42 => 'cmgmyr\\phploc\\addunique',
        43 => 'cmgmyr\\phploc\\addtoarray',
        44 => 'cmgmyr\\phploc\\increment',
        45 => 'cmgmyr\\phploc\\check',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\cmgmyr\\phploc\\src\\Exception\\ArgumentsBuilderException.php' => 
    array (
      0 => 'b322f19636a4849d144788bbca6a539ac64224d0',
      1 => 
      array (
        0 => 'cmgmyr\\phploc\\argumentsbuilderexception',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\cmgmyr\\phploc\\src\\Exception\\Exception.php' => 
    array (
      0 => '69333db734d5ca0c12ad6367109567e1d480111a',
      1 => 
      array (
        0 => 'cmgmyr\\phploc\\exception',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\cmgmyr\\phploc\\src\\Exception\\RuntimeException.php' => 
    array (
      0 => '563625b8b06b0e9e788faf6d13b3be606d172ae5',
      1 => 
      array (
        0 => 'cmgmyr\\phploc\\runtimeexception',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\cmgmyr\\phploc\\src\\Log\\Csv.php' => 
    array (
      0 => 'ce5111f296e39b839167e821ed99b2de27dc8f71',
      1 => 
      array (
        0 => 'cmgmyr\\phploc\\log\\csv',
      ),
      2 => 
      array (
        0 => 'cmgmyr\\phploc\\log\\printresult',
        1 => 'cmgmyr\\phploc\\log\\getkeysline',
        2 => 'cmgmyr\\phploc\\log\\getvaluesline',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\cmgmyr\\phploc\\src\\Log\\Json.php' => 
    array (
      0 => '2d0feebb9bbcc8b7b684bde9bdd8092110a9c87f',
      1 => 
      array (
        0 => 'cmgmyr\\phploc\\log\\json',
      ),
      2 => 
      array (
        0 => 'cmgmyr\\phploc\\log\\printresult',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\cmgmyr\\phploc\\src\\Log\\Text.php' => 
    array (
      0 => '9460409af1172c7114b9b017d27a928d6ae2380c',
      1 => 
      array (
        0 => 'cmgmyr\\phploc\\log\\text',
      ),
      2 => 
      array (
        0 => 'cmgmyr\\phploc\\log\\printresult',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\cmgmyr\\phploc\\src\\Log\\Xml.php' => 
    array (
      0 => '50598c4e8b706182b5271e823e02a728777ba7bf',
      1 => 
      array (
        0 => 'cmgmyr\\phploc\\log\\xml',
      ),
      2 => 
      array (
        0 => 'cmgmyr\\phploc\\log\\printresult',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\cmgmyr\\phploc\\src\\Publisher.php' => 
    array (
      0 => 'a445850f7377b5c17898e1228dc1323e8895332c',
      1 => 
      array (
        0 => 'cmgmyr\\phploc\\publisher',
      ),
      2 => 
      array (
        0 => 'cmgmyr\\phploc\\__construct',
        1 => 'cmgmyr\\phploc\\getdirectories',
        2 => 'cmgmyr\\phploc\\getfiles',
        3 => 'cmgmyr\\phploc\\getlines',
        4 => 'cmgmyr\\phploc\\getcommentlines',
        5 => 'cmgmyr\\phploc\\getnoncommentlines',
        6 => 'cmgmyr\\phploc\\getlogicallines',
        7 => 'cmgmyr\\phploc\\getclasslines',
        8 => 'cmgmyr\\phploc\\getaverageclasslength',
        9 => 'cmgmyr\\phploc\\getminimumclasslength',
        10 => 'cmgmyr\\phploc\\getmaximumclasslength',
        11 => 'cmgmyr\\phploc\\getaveragemethodlength',
        12 => 'cmgmyr\\phploc\\getminimummethodlength',
        13 => 'cmgmyr\\phploc\\getmaximummethodlength',
        14 => 'cmgmyr\\phploc\\getaveragemethodsperclass',
        15 => 'cmgmyr\\phploc\\getminimummethodsperclass',
        16 => 'cmgmyr\\phploc\\getmaximummethodsperclass',
        17 => 'cmgmyr\\phploc\\getfunctionlines',
        18 => 'cmgmyr\\phploc\\getaveragefunctionlength',
        19 => 'cmgmyr\\phploc\\getnotinclassesorfunctions',
        20 => 'cmgmyr\\phploc\\getcomplexity',
        21 => 'cmgmyr\\phploc\\getmethodcomplexity',
        22 => 'cmgmyr\\phploc\\getaveragecomplexityperlogicalline',
        23 => 'cmgmyr\\phploc\\getaveragecomplexityperclass',
        24 => 'cmgmyr\\phploc\\getminimumclasscomplexity',
        25 => 'cmgmyr\\phploc\\getmaximumclasscomplexity',
        26 => 'cmgmyr\\phploc\\getaveragecomplexitypermethod',
        27 => 'cmgmyr\\phploc\\getminimummethodcomplexity',
        28 => 'cmgmyr\\phploc\\getmaximummethodcomplexity',
        29 => 'cmgmyr\\phploc\\getglobalaccesses',
        30 => 'cmgmyr\\phploc\\getglobalconstantaccesses',
        31 => 'cmgmyr\\phploc\\getglobalvariableaccesses',
        32 => 'cmgmyr\\phploc\\getsuperglobalvariableaccesses',
        33 => 'cmgmyr\\phploc\\getattributeaccesses',
        34 => 'cmgmyr\\phploc\\getnonstaticattributeaccesses',
        35 => 'cmgmyr\\phploc\\getstaticattributeaccesses',
        36 => 'cmgmyr\\phploc\\getmethodcalls',
        37 => 'cmgmyr\\phploc\\getnonstaticmethodcalls',
        38 => 'cmgmyr\\phploc\\getstaticmethodcalls',
        39 => 'cmgmyr\\phploc\\getnamespaces',
        40 => 'cmgmyr\\phploc\\getinterfaces',
        41 => 'cmgmyr\\phploc\\gettraits',
        42 => 'cmgmyr\\phploc\\getclasses',
        43 => 'cmgmyr\\phploc\\getabstractclasses',
        44 => 'cmgmyr\\phploc\\getconcreteclasses',
        45 => 'cmgmyr\\phploc\\getfinalclasses',
        46 => 'cmgmyr\\phploc\\getnonfinalclasses',
        47 => 'cmgmyr\\phploc\\getmethods',
        48 => 'cmgmyr\\phploc\\getnonstaticmethods',
        49 => 'cmgmyr\\phploc\\getstaticmethods',
        50 => 'cmgmyr\\phploc\\getpublicmethods',
        51 => 'cmgmyr\\phploc\\getnonpublicmethods',
        52 => 'cmgmyr\\phploc\\getprotectedmethods',
        53 => 'cmgmyr\\phploc\\getprivatemethods',
        54 => 'cmgmyr\\phploc\\getfunctions',
        55 => 'cmgmyr\\phploc\\getnamedfunctions',
        56 => 'cmgmyr\\phploc\\getanonymousfunctions',
        57 => 'cmgmyr\\phploc\\getconstants',
        58 => 'cmgmyr\\phploc\\getglobalconstants',
        59 => 'cmgmyr\\phploc\\getpublicclassconstants',
        60 => 'cmgmyr\\phploc\\getnonpublicclassconstants',
        61 => 'cmgmyr\\phploc\\getclassconstants',
        62 => 'cmgmyr\\phploc\\gettestclasses',
        63 => 'cmgmyr\\phploc\\gettestmethods',
        64 => 'cmgmyr\\phploc\\toarray',
        65 => 'cmgmyr\\phploc\\getaverage',
        66 => 'cmgmyr\\phploc\\getcount',
        67 => 'cmgmyr\\phploc\\getsum',
        68 => 'cmgmyr\\phploc\\getmaximum',
        69 => 'cmgmyr\\phploc\\getminimum',
        70 => 'cmgmyr\\phploc\\getvalue',
        71 => 'cmgmyr\\phploc\\divide',
      ),
      3 => 
      array (
      ),
    ),
  ),
));