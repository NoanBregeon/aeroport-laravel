<?php declare(strict_types = 1);

// odsl-C:/code/aeroport-laravel/vendor/composer/../phpunit/php-timer/src/
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v1',
   'data' => 
  array (
    'C:\\code\\aeroport-laravel\\vendor\\phpunit\\php-timer\\src\\Duration.php' => 
    array (
      0 => '0fe375970a9fb84e9ac087e528852dc16adc5774',
      1 => 
      array (
        0 => 'sebastianbergmann\\timer\\duration',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\timer\\frommicroseconds',
        1 => 'sebastianbergmann\\timer\\fromnanoseconds',
        2 => 'sebastianbergmann\\timer\\__construct',
        3 => 'sebastianbergmann\\timer\\asnanoseconds',
        4 => 'sebastianbergmann\\timer\\asmicroseconds',
        5 => 'sebastianbergmann\\timer\\asmilliseconds',
        6 => 'sebastianbergmann\\timer\\asseconds',
        7 => 'sebastianbergmann\\timer\\asstring',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\phpunit\\php-timer\\src\\exceptions\\Exception.php' => 
    array (
      0 => '585b1208820c28f65d4ccebe577ca93444b2364c',
      1 => 
      array (
        0 => 'sebastianbergmann\\timer\\exception',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\phpunit\\php-timer\\src\\exceptions\\NoActiveTimerException.php' => 
    array (
      0 => '83b14a0d942e084460fc373c896ecf868ea4b7b7',
      1 => 
      array (
        0 => 'sebastianbergmann\\timer\\noactivetimerexception',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\phpunit\\php-timer\\src\\exceptions\\TimeSinceStartOfRequestNotAvailableException.php' => 
    array (
      0 => '31c00ec28beba93d9853845c77887597821c9ee6',
      1 => 
      array (
        0 => 'sebastianbergmann\\timer\\timesincestartofrequestnotavailableexception',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\phpunit\\php-timer\\src\\ResourceUsageFormatter.php' => 
    array (
      0 => 'c89198c7ee4a06fb1337ba8af9ed1440d3a45a4a',
      1 => 
      array (
        0 => 'sebastianbergmann\\timer\\resourceusageformatter',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\timer\\resourceusage',
        1 => 'sebastianbergmann\\timer\\resourceusagesincestartofrequest',
        2 => 'sebastianbergmann\\timer\\bytestostring',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\phpunit\\php-timer\\src\\Timer.php' => 
    array (
      0 => '98c58a0323a73d447c560c257e7015e26e5d7bdd',
      1 => 
      array (
        0 => 'sebastianbergmann\\timer\\timer',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\timer\\start',
        1 => 'sebastianbergmann\\timer\\stop',
      ),
      3 => 
      array (
      ),
    ),
  ),
));