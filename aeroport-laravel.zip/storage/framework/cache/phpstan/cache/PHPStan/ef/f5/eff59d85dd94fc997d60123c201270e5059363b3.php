<?php declare(strict_types = 1);

// odsl-C:/code/aeroport-laravel/vendor/composer/../symfony/polyfill-php85/Resources/stubs
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v1',
   'data' => 
  array (
    'C:\\code\\aeroport-laravel\\vendor\\symfony\\polyfill-php85\\Resources\\stubs\\NoDiscard.php' => 
    array (
      0 => '82efed00d9e63aeb442118c2e2b9fe9e252f3619',
      1 => 
      array (
        0 => 'nodiscard',
      ),
      2 => 
      array (
        0 => '__construct',
      ),
      3 => 
      array (
      ),
    ),
  ),
));