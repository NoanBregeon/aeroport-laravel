<?php declare(strict_types = 1);

// odsl-C:/code/aeroport-laravel/vendor/composer/../sebastian/cli-parser/src/
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v1',
   'data' => 
  array (
    'C:\\code\\aeroport-laravel\\vendor\\sebastian\\cli-parser\\src\\exceptions\\AmbiguousOptionException.php' => 
    array (
      0 => '5cbf71bd59993fba2e04573fd2af3e896ba6cb44',
      1 => 
      array (
        0 => 'sebastianbergmann\\cliparser\\ambiguousoptionexception',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\cliparser\\__construct',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\sebastian\\cli-parser\\src\\exceptions\\Exception.php' => 
    array (
      0 => '9f4eed104c2dff7495ead0ec11c708ab090e9cef',
      1 => 
      array (
        0 => 'sebastianbergmann\\cliparser\\exception',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\sebastian\\cli-parser\\src\\exceptions\\OptionDoesNotAllowArgumentException.php' => 
    array (
      0 => 'cda9342e391e62cf0d074e78b888e34325ac1d58',
      1 => 
      array (
        0 => 'sebastianbergmann\\cliparser\\optiondoesnotallowargumentexception',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\cliparser\\__construct',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\sebastian\\cli-parser\\src\\exceptions\\RequiredOptionArgumentMissingException.php' => 
    array (
      0 => '5f59479dd69423f980e20119ac5a3462e87cf3e9',
      1 => 
      array (
        0 => 'sebastianbergmann\\cliparser\\requiredoptionargumentmissingexception',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\cliparser\\__construct',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\sebastian\\cli-parser\\src\\exceptions\\UnknownOptionException.php' => 
    array (
      0 => 'f0605798d3c3ae00645df1385df6c8d62f211b0f',
      1 => 
      array (
        0 => 'sebastianbergmann\\cliparser\\unknownoptionexception',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\cliparser\\__construct',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\sebastian\\cli-parser\\src\\Parser.php' => 
    array (
      0 => '517dbea4d8a6272691f0225149eb79b272a53694',
      1 => 
      array (
        0 => 'sebastianbergmann\\cliparser\\parser',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\cliparser\\parse',
        1 => 'sebastianbergmann\\cliparser\\parseshortoption',
        2 => 'sebastianbergmann\\cliparser\\parselongoption',
      ),
      3 => 
      array (
      ),
    ),
  ),
));