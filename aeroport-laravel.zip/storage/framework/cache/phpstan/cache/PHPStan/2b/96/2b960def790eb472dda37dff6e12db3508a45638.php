<?php declare(strict_types = 1);

// odsl-C:/code/aeroport-laravel/vendor/composer/../symfony/polyfill-php84/Resources/stubs
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v1',
   'data' => 
  array (
    'C:\\code\\aeroport-laravel\\vendor\\symfony\\polyfill-php84\\Resources\\stubs\\Deprecated.php' => 
    array (
      0 => 'ae070590b6e01ff65312d593de5fa704cca8b2ee',
      1 => 
      array (
        0 => 'deprecated',
      ),
      2 => 
      array (
        0 => '__construct',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\symfony\\polyfill-php84\\Resources\\stubs\\ReflectionConstant.php' => 
    array (
      0 => '8274c49d807e0942cccc1ac18bbb3eac494fc408',
      1 => 
      array (
        0 => 'reflectionconstant',
      ),
      2 => 
      array (
        0 => '__construct',
        1 => 'getname',
        2 => 'getvalue',
        3 => 'getnamespacename',
        4 => 'getshortname',
        5 => 'isdeprecated',
        6 => '__tostring',
        7 => '__sleep',
        8 => '__wakeup',
      ),
      3 => 
      array (
      ),
    ),
  ),
));