<?php declare(strict_types = 1);

// odsl-C:/code/aeroport-laravel/vendor/composer/../symfony/polyfill-php81/Resources/stubs
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v1',
   'data' => 
  array (
    'C:\\code\\aeroport-laravel\\vendor\\symfony\\polyfill-php81\\Resources\\stubs\\CURLStringFile.php' => 
    array (
      0 => '4c6d1cf0b7fc7da5dc868681dd20cd207692d0cd',
      1 => 
      array (
        0 => 'curlstringfile',
      ),
      2 => 
      array (
        0 => '__construct',
        1 => '__set',
        2 => '__isset',
        3 => '__get',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\symfony\\polyfill-php81\\Resources\\stubs\\ReturnTypeWillChange.php' => 
    array (
      0 => 'bb16ba8acfd1386faf29cf2816814285f2c53466',
      1 => 
      array (
        0 => 'returntypewillchange',
      ),
      2 => 
      array (
        0 => '__construct',
      ),
      3 => 
      array (
      ),
    ),
  ),
));