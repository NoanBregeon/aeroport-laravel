<?php declare(strict_types = 1);

// odsl-C:/code/aeroport-laravel/vendor/composer/../phpunit/php-invoker/src/
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v1',
   'data' => 
  array (
    'C:\\code\\aeroport-laravel\\vendor\\phpunit\\php-invoker\\src\\exceptions\\Exception.php' => 
    array (
      0 => 'e609d0d0f184625197ba28482c4c64be5522d7e7',
      1 => 
      array (
        0 => 'sebastianbergmann\\invoker\\exception',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\phpunit\\php-invoker\\src\\exceptions\\ProcessControlExtensionNotLoadedException.php' => 
    array (
      0 => 'beccc7e344258fc935b2fb16c70a3031dc8774f8',
      1 => 
      array (
        0 => 'sebastianbergmann\\invoker\\processcontrolextensionnotloadedexception',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\invoker\\__construct',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\phpunit\\php-invoker\\src\\exceptions\\TimeoutException.php' => 
    array (
      0 => 'a7dee3db7905c74e0e49f19523e8774516b7911a',
      1 => 
      array (
        0 => 'sebastianbergmann\\invoker\\timeoutexception',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\phpunit\\php-invoker\\src\\Invoker.php' => 
    array (
      0 => '775668352efb01412200aeeec37e20c07aee4fa6',
      1 => 
      array (
        0 => 'sebastianbergmann\\invoker\\invoker',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\invoker\\invoke',
        1 => 'sebastianbergmann\\invoker\\caninvokewithtimeout',
      ),
      3 => 
      array (
      ),
    ),
  ),
));