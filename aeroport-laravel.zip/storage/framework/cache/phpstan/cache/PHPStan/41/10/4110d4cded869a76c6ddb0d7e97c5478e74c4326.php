<?php declare(strict_types = 1);

// odsl-C:/code/aeroport-laravel/vendor/composer/../sebastian/code-unit/src/
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v1',
   'data' => 
  array (
    'C:\\code\\aeroport-laravel\\vendor\\sebastian\\code-unit\\src\\ClassMethodUnit.php' => 
    array (
      0 => '5d3ce9f698e675b13368d95a5e116c0dfbd46e73',
      1 => 
      array (
        0 => 'sebastianbergmann\\codeunit\\classmethodunit',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\codeunit\\isclassmethod',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\sebastian\\code-unit\\src\\ClassUnit.php' => 
    array (
      0 => '25b8df3d7044963bd087820b2f99ba825b41dda5',
      1 => 
      array (
        0 => 'sebastianbergmann\\codeunit\\classunit',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\codeunit\\isclass',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\sebastian\\code-unit\\src\\CodeUnit.php' => 
    array (
      0 => 'a4e326a3a4495b59d511d5b01a6e76399b6b4610',
      1 => 
      array (
        0 => 'sebastianbergmann\\codeunit\\codeunit',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\codeunit\\forclass',
        1 => 'sebastianbergmann\\codeunit\\forclassmethod',
        2 => 'sebastianbergmann\\codeunit\\forfilewithabsolutepath',
        3 => 'sebastianbergmann\\codeunit\\forinterface',
        4 => 'sebastianbergmann\\codeunit\\forinterfacemethod',
        5 => 'sebastianbergmann\\codeunit\\fortrait',
        6 => 'sebastianbergmann\\codeunit\\fortraitmethod',
        7 => 'sebastianbergmann\\codeunit\\forfunction',
        8 => 'sebastianbergmann\\codeunit\\__construct',
        9 => 'sebastianbergmann\\codeunit\\name',
        10 => 'sebastianbergmann\\codeunit\\sourcefilename',
        11 => 'sebastianbergmann\\codeunit\\sourcelines',
        12 => 'sebastianbergmann\\codeunit\\isclass',
        13 => 'sebastianbergmann\\codeunit\\isclassmethod',
        14 => 'sebastianbergmann\\codeunit\\isinterface',
        15 => 'sebastianbergmann\\codeunit\\isinterfacemethod',
        16 => 'sebastianbergmann\\codeunit\\istrait',
        17 => 'sebastianbergmann\\codeunit\\istraitmethod',
        18 => 'sebastianbergmann\\codeunit\\isfunction',
        19 => 'sebastianbergmann\\codeunit\\isfile',
        20 => 'sebastianbergmann\\codeunit\\ensurefileexistsandisreadable',
        21 => 'sebastianbergmann\\codeunit\\ensureuserdefinedclass',
        22 => 'sebastianbergmann\\codeunit\\ensureuserdefinedinterface',
        23 => 'sebastianbergmann\\codeunit\\ensureuserdefinedtrait',
        24 => 'sebastianbergmann\\codeunit\\reflectorforclassmethod',
        25 => 'sebastianbergmann\\codeunit\\reflectorforfunction',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\sebastian\\code-unit\\src\\CodeUnitCollection.php' => 
    array (
      0 => 'e64eb401fd9e3ca74be544e1cbe355e1748d2a1c',
      1 => 
      array (
        0 => 'sebastianbergmann\\codeunit\\codeunitcollection',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\codeunit\\fromlist',
        1 => 'sebastianbergmann\\codeunit\\__construct',
        2 => 'sebastianbergmann\\codeunit\\asarray',
        3 => 'sebastianbergmann\\codeunit\\getiterator',
        4 => 'sebastianbergmann\\codeunit\\count',
        5 => 'sebastianbergmann\\codeunit\\isempty',
        6 => 'sebastianbergmann\\codeunit\\mergewith',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\sebastian\\code-unit\\src\\CodeUnitCollectionIterator.php' => 
    array (
      0 => '05f0a9f3c3e3d77fb507259dcbc2e9e459952335',
      1 => 
      array (
        0 => 'sebastianbergmann\\codeunit\\codeunitcollectioniterator',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\codeunit\\__construct',
        1 => 'sebastianbergmann\\codeunit\\rewind',
        2 => 'sebastianbergmann\\codeunit\\valid',
        3 => 'sebastianbergmann\\codeunit\\key',
        4 => 'sebastianbergmann\\codeunit\\current',
        5 => 'sebastianbergmann\\codeunit\\next',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\sebastian\\code-unit\\src\\exceptions\\Exception.php' => 
    array (
      0 => '845bad43c96c716a8a1c466f18e2e2268c9e57dc',
      1 => 
      array (
        0 => 'sebastianbergmann\\codeunit\\exception',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\sebastian\\code-unit\\src\\exceptions\\InvalidCodeUnitException.php' => 
    array (
      0 => '1f85639a6a68466fb906fd5fd1ccd5c7cc89e4e8',
      1 => 
      array (
        0 => 'sebastianbergmann\\codeunit\\invalidcodeunitexception',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\sebastian\\code-unit\\src\\exceptions\\NoTraitException.php' => 
    array (
      0 => '5ff90049fe5f9cfe833dfe9c85adfdc0a0737e02',
      1 => 
      array (
        0 => 'sebastianbergmann\\codeunit\\notraitexception',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\sebastian\\code-unit\\src\\exceptions\\ReflectionException.php' => 
    array (
      0 => '6d9aa134fe89ef240bf3f9358ec3128b54238a3f',
      1 => 
      array (
        0 => 'sebastianbergmann\\codeunit\\reflectionexception',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\sebastian\\code-unit\\src\\FileUnit.php' => 
    array (
      0 => '7cfe216e8ff57e9b58d5ba2e2b5a66178b4e9175',
      1 => 
      array (
        0 => 'sebastianbergmann\\codeunit\\fileunit',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\codeunit\\isfile',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\sebastian\\code-unit\\src\\FunctionUnit.php' => 
    array (
      0 => 'd388c91f962c0421c4c8bf6df8b91480759b5f6e',
      1 => 
      array (
        0 => 'sebastianbergmann\\codeunit\\functionunit',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\codeunit\\isfunction',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\sebastian\\code-unit\\src\\InterfaceMethodUnit.php' => 
    array (
      0 => 'c4c4aaad3fe33e0296d277c345ecb69eb286130a',
      1 => 
      array (
        0 => 'sebastianbergmann\\codeunit\\interfacemethodunit',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\codeunit\\isinterfacemethod',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\sebastian\\code-unit\\src\\InterfaceUnit.php' => 
    array (
      0 => 'f60d06a0aa4131c281531160d4ef215551c7af50',
      1 => 
      array (
        0 => 'sebastianbergmann\\codeunit\\interfaceunit',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\codeunit\\isinterface',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\sebastian\\code-unit\\src\\Mapper.php' => 
    array (
      0 => 'cc00facc744914fee9ff117798db3c45c43204bb',
      1 => 
      array (
        0 => 'sebastianbergmann\\codeunit\\mapper',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\codeunit\\codeunitstosourcelines',
        1 => 'sebastianbergmann\\codeunit\\stringtocodeunits',
        2 => 'sebastianbergmann\\codeunit\\isuserdefinedfunction',
        3 => 'sebastianbergmann\\codeunit\\isuserdefinedclass',
        4 => 'sebastianbergmann\\codeunit\\isuserdefinedinterface',
        5 => 'sebastianbergmann\\codeunit\\isuserdefinedtrait',
        6 => 'sebastianbergmann\\codeunit\\isuserdefinedmethod',
        7 => 'sebastianbergmann\\codeunit\\traits',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\sebastian\\code-unit\\src\\TraitMethodUnit.php' => 
    array (
      0 => '946e7a09676a0151a32e55ecb283911c950c6c20',
      1 => 
      array (
        0 => 'sebastianbergmann\\codeunit\\traitmethodunit',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\codeunit\\istraitmethod',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\sebastian\\code-unit\\src\\TraitUnit.php' => 
    array (
      0 => '00e0ebf71d017519306cc46e8fc8adc50a083fce',
      1 => 
      array (
        0 => 'sebastianbergmann\\codeunit\\traitunit',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\codeunit\\istrait',
      ),
      3 => 
      array (
      ),
    ),
  ),
));