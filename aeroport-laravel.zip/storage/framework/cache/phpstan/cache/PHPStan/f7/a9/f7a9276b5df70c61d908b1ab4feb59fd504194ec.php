<?php declare(strict_types = 1);

// odsl-C:/code/aeroport-laravel/vendor/composer/../sebastian/environment/src/
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v1',
   'data' => 
  array (
    'C:\\code\\aeroport-laravel\\vendor\\sebastian\\environment\\src\\Console.php' => 
    array (
      0 => '8dba4957948bc4e425c2c8eda096a82d61d75809',
      1 => 
      array (
        0 => 'sebastianbergmann\\environment\\console',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\environment\\hascolorsupport',
        1 => 'sebastianbergmann\\environment\\getnumberofcolumns',
        2 => 'sebastianbergmann\\environment\\isinteractive',
        3 => 'sebastianbergmann\\environment\\iswindows',
        4 => 'sebastianbergmann\\environment\\getnumberofcolumnsinteractive',
        5 => 'sebastianbergmann\\environment\\getnumberofcolumnswindows',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\sebastian\\environment\\src\\Runtime.php' => 
    array (
      0 => 'c3834066a86f1274440289f8a35b4ea8242b0536',
      1 => 
      array (
        0 => 'sebastianbergmann\\environment\\runtime',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\environment\\cancollectcodecoverage',
        1 => 'sebastianbergmann\\environment\\discardscomments',
        2 => 'sebastianbergmann\\environment\\performsjustintimecompilation',
        3 => 'sebastianbergmann\\environment\\getrawbinary',
        4 => 'sebastianbergmann\\environment\\getbinary',
        5 => 'sebastianbergmann\\environment\\getnamewithversion',
        6 => 'sebastianbergmann\\environment\\getnamewithversionandcodecoveragedriver',
        7 => 'sebastianbergmann\\environment\\getname',
        8 => 'sebastianbergmann\\environment\\getvendorurl',
        9 => 'sebastianbergmann\\environment\\getversion',
        10 => 'sebastianbergmann\\environment\\hasxdebug',
        11 => 'sebastianbergmann\\environment\\isphp',
        12 => 'sebastianbergmann\\environment\\isphpdbg',
        13 => 'sebastianbergmann\\environment\\hasphpdbgcodecoverage',
        14 => 'sebastianbergmann\\environment\\haspcov',
        15 => 'sebastianbergmann\\environment\\getcurrentsettings',
        16 => 'sebastianbergmann\\environment\\isopcacheactive',
      ),
      3 => 
      array (
      ),
    ),
  ),
));