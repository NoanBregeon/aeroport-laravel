<?php declare(strict_types = 1);

// odsl-C:/code/aeroport-laravel/vendor/composer/../theseer/tokenizer/src/
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v1',
   'data' => 
  array (
    'C:\\code\\aeroport-laravel\\vendor\\theseer\\tokenizer\\src\\Exception.php' => 
    array (
      0 => 'f1984821ed73363a5ede6d1cd570898e01148c23',
      1 => 
      array (
        0 => 'theseer\\tokenizer\\exception',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\theseer\\tokenizer\\src\\NamespaceUri.php' => 
    array (
      0 => 'befc3004af28f6a2154c9b9b1203ef18e16a49f2',
      1 => 
      array (
        0 => 'theseer\\tokenizer\\namespaceuri',
      ),
      2 => 
      array (
        0 => 'theseer\\tokenizer\\__construct',
        1 => 'theseer\\tokenizer\\asstring',
        2 => 'theseer\\tokenizer\\ensurevaliduri',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\theseer\\tokenizer\\src\\NamespaceUriException.php' => 
    array (
      0 => 'eb0118a14b93df2a4b029d40f6b8acbf110999d6',
      1 => 
      array (
        0 => 'theseer\\tokenizer\\namespaceuriexception',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\theseer\\tokenizer\\src\\Token.php' => 
    array (
      0 => '72dfc3764b5904229fffdbd455692c1f6f453e03',
      1 => 
      array (
        0 => 'theseer\\tokenizer\\token',
      ),
      2 => 
      array (
        0 => 'theseer\\tokenizer\\__construct',
        1 => 'theseer\\tokenizer\\getline',
        2 => 'theseer\\tokenizer\\getname',
        3 => 'theseer\\tokenizer\\getvalue',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\theseer\\tokenizer\\src\\TokenCollection.php' => 
    array (
      0 => '7bdadf81e5e4526ef85de2a1ef6742eae926a6d1',
      1 => 
      array (
        0 => 'theseer\\tokenizer\\tokencollection',
      ),
      2 => 
      array (
        0 => 'theseer\\tokenizer\\addtoken',
        1 => 'theseer\\tokenizer\\getiterator',
        2 => 'theseer\\tokenizer\\count',
        3 => 'theseer\\tokenizer\\offsetexists',
        4 => 'theseer\\tokenizer\\offsetget',
        5 => 'theseer\\tokenizer\\offsetset',
        6 => 'theseer\\tokenizer\\offsetunset',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\theseer\\tokenizer\\src\\TokenCollectionException.php' => 
    array (
      0 => '9c4af3c1624653bf11e5a5291e3c1f447a147c39',
      1 => 
      array (
        0 => 'theseer\\tokenizer\\tokencollectionexception',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\theseer\\tokenizer\\src\\Tokenizer.php' => 
    array (
      0 => '3e525c5b33efe63c3bb6633ecaf835987891c1ae',
      1 => 
      array (
        0 => 'theseer\\tokenizer\\tokenizer',
      ),
      2 => 
      array (
        0 => 'theseer\\tokenizer\\parse',
        1 => 'theseer\\tokenizer\\fillblanks',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\theseer\\tokenizer\\src\\XMLSerializer.php' => 
    array (
      0 => '62d2debc62c795a4036c61fe302e05798ba6f9b9',
      1 => 
      array (
        0 => 'theseer\\tokenizer\\xmlserializer',
      ),
      2 => 
      array (
        0 => 'theseer\\tokenizer\\__construct',
        1 => 'theseer\\tokenizer\\todom',
        2 => 'theseer\\tokenizer\\toxml',
      ),
      3 => 
      array (
      ),
    ),
  ),
));