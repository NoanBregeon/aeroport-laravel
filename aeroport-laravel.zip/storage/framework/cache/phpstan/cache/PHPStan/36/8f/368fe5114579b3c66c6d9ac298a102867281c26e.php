<?php declare(strict_types = 1);

// odsl-C:/code/aeroport-laravel/vendor/composer/../nette/schema/src/
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v1',
   'data' => 
  array (
    'C:\\code\\aeroport-laravel\\vendor\\nette\\schema\\src\\Schema\\Context.php' => 
    array (
      0 => 'e42b7ff1a83d6ce0575bfb1351e457abc6770998',
      1 => 
      array (
        0 => 'nette\\schema\\context',
      ),
      2 => 
      array (
        0 => 'nette\\schema\\adderror',
        1 => 'nette\\schema\\addwarning',
        2 => 'nette\\schema\\createchecker',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\nette\\schema\\src\\Schema\\DynamicParameter.php' => 
    array (
      0 => '4192e262c5c981d77aad158604c245d054f83e90',
      1 => 
      array (
        0 => 'nette\\schema\\dynamicparameter',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\nette\\schema\\src\\Schema\\Elements\\AnyOf.php' => 
    array (
      0 => 'abb95c11af0f5f48025d83d34ae43abe8452ca53',
      1 => 
      array (
        0 => 'nette\\schema\\elements\\anyof',
      ),
      2 => 
      array (
        0 => 'nette\\schema\\elements\\__construct',
        1 => 'nette\\schema\\elements\\firstisdefault',
        2 => 'nette\\schema\\elements\\nullable',
        3 => 'nette\\schema\\elements\\dynamic',
        4 => 'nette\\schema\\elements\\normalize',
        5 => 'nette\\schema\\elements\\merge',
        6 => 'nette\\schema\\elements\\complete',
        7 => 'nette\\schema\\elements\\findalternative',
        8 => 'nette\\schema\\elements\\completedefault',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\nette\\schema\\src\\Schema\\Elements\\Base.php' => 
    array (
      0 => 'acc9af449a6664ad322de07c01274562fc7c8266',
      1 => 
      array (
        0 => 'nette\\schema\\elements\\base',
      ),
      2 => 
      array (
        0 => 'nette\\schema\\elements\\default',
        1 => 'nette\\schema\\elements\\required',
        2 => 'nette\\schema\\elements\\before',
        3 => 'nette\\schema\\elements\\castto',
        4 => 'nette\\schema\\elements\\transform',
        5 => 'nette\\schema\\elements\\assert',
        6 => 'nette\\schema\\elements\\deprecated',
        7 => 'nette\\schema\\elements\\completedefault',
        8 => 'nette\\schema\\elements\\donormalize',
        9 => 'nette\\schema\\elements\\dodeprecation',
        10 => 'nette\\schema\\elements\\dotransform',
        11 => 'nette\\schema\\elements\\dovalidate',
        12 => 'nette\\schema\\elements\\dovalidaterange',
        13 => 'nette\\schema\\elements\\dofinalize',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\nette\\schema\\src\\Schema\\Elements\\Structure.php' => 
    array (
      0 => '7a8ad015015796768136799f026cafc1945dbddf',
      1 => 
      array (
        0 => 'nette\\schema\\elements\\structure',
      ),
      2 => 
      array (
        0 => 'nette\\schema\\elements\\__construct',
        1 => 'nette\\schema\\elements\\default',
        2 => 'nette\\schema\\elements\\min',
        3 => 'nette\\schema\\elements\\max',
        4 => 'nette\\schema\\elements\\otheritems',
        5 => 'nette\\schema\\elements\\skipdefaults',
        6 => 'nette\\schema\\elements\\extend',
        7 => 'nette\\schema\\elements\\getshape',
        8 => 'nette\\schema\\elements\\normalize',
        9 => 'nette\\schema\\elements\\merge',
        10 => 'nette\\schema\\elements\\complete',
        11 => 'nette\\schema\\elements\\validateitems',
        12 => 'nette\\schema\\elements\\completedefault',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\nette\\schema\\src\\Schema\\Elements\\Type.php' => 
    array (
      0 => '3a5643c9c47ef0bd09008187aa8db6c25c9bfdcf',
      1 => 
      array (
        0 => 'nette\\schema\\elements\\type',
      ),
      2 => 
      array (
        0 => 'nette\\schema\\elements\\__construct',
        1 => 'nette\\schema\\elements\\nullable',
        2 => 'nette\\schema\\elements\\mergedefaults',
        3 => 'nette\\schema\\elements\\dynamic',
        4 => 'nette\\schema\\elements\\min',
        5 => 'nette\\schema\\elements\\max',
        6 => 'nette\\schema\\elements\\items',
        7 => 'nette\\schema\\elements\\pattern',
        8 => 'nette\\schema\\elements\\normalize',
        9 => 'nette\\schema\\elements\\merge',
        10 => 'nette\\schema\\elements\\complete',
        11 => 'nette\\schema\\elements\\validateitems',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\nette\\schema\\src\\Schema\\Expect.php' => 
    array (
      0 => '7afdb71012d8c0e0833ea690e6bc762e8f3e5cc3',
      1 => 
      array (
        0 => 'nette\\schema\\expect',
      ),
      2 => 
      array (
        0 => 'nette\\schema\\__callstatic',
        1 => 'nette\\schema\\type',
        2 => 'nette\\schema\\anyof',
        3 => 'nette\\schema\\structure',
        4 => 'nette\\schema\\from',
        5 => 'nette\\schema\\array',
        6 => 'nette\\schema\\arrayof',
        7 => 'nette\\schema\\listof',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\nette\\schema\\src\\Schema\\Helpers.php' => 
    array (
      0 => 'f9ea82ab63f9f00cab7f2fd6edd6db74884c5621',
      1 => 
      array (
        0 => 'nette\\schema\\helpers',
      ),
      2 => 
      array (
        0 => 'nette\\schema\\merge',
        1 => 'nette\\schema\\getpropertytype',
        2 => 'nette\\schema\\parseannotation',
        3 => 'nette\\schema\\formatvalue',
        4 => 'nette\\schema\\validatetype',
        5 => 'nette\\schema\\validaterange',
        6 => 'nette\\schema\\isinrange',
        7 => 'nette\\schema\\validatepattern',
        8 => 'nette\\schema\\getcaststrategy',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\nette\\schema\\src\\Schema\\Message.php' => 
    array (
      0 => 'ed4467647efc08d0fffd1f6a8cbcedd95bdc1bde',
      1 => 
      array (
        0 => 'nette\\schema\\message',
      ),
      2 => 
      array (
        0 => 'nette\\schema\\__construct',
        1 => 'nette\\schema\\tostring',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\nette\\schema\\src\\Schema\\Processor.php' => 
    array (
      0 => 'efa684244f9e6f22300316afa634a0102d8973ad',
      1 => 
      array (
        0 => 'nette\\schema\\processor',
      ),
      2 => 
      array (
        0 => 'nette\\schema\\skipdefaults',
        1 => 'nette\\schema\\process',
        2 => 'nette\\schema\\processmultiple',
        3 => 'nette\\schema\\getwarnings',
        4 => 'nette\\schema\\throwserrors',
        5 => 'nette\\schema\\createcontext',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\nette\\schema\\src\\Schema\\Schema.php' => 
    array (
      0 => '24a8422581be56a210c0a4c610af3aeaaeca779a',
      1 => 
      array (
        0 => 'nette\\schema\\schema',
      ),
      2 => 
      array (
        0 => 'nette\\schema\\normalize',
        1 => 'nette\\schema\\merge',
        2 => 'nette\\schema\\complete',
        3 => 'nette\\schema\\completedefault',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\nette\\schema\\src\\Schema\\ValidationException.php' => 
    array (
      0 => 'debe8d841f9dc68cc92527f0d6fb30ddc884d39a',
      1 => 
      array (
        0 => 'nette\\schema\\validationexception',
      ),
      2 => 
      array (
        0 => 'nette\\schema\\__construct',
        1 => 'nette\\schema\\getmessages',
        2 => 'nette\\schema\\getmessageobjects',
      ),
      3 => 
      array (
      ),
    ),
  ),
));