<?php declare(strict_types = 1);

// odsl-C:/code/aeroport-laravel/vendor/composer/../symfony/polyfill-php83/Resources/stubs
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v1',
   'data' => 
  array (
    'C:\\code\\aeroport-laravel\\vendor\\symfony\\polyfill-php83\\Resources\\stubs\\DateError.php' => 
    array (
      0 => '507d40e4c8120159602a96ad7f79f2747c075832',
      1 => 
      array (
        0 => 'dateerror',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\symfony\\polyfill-php83\\Resources\\stubs\\DateException.php' => 
    array (
      0 => 'af1baabcbe518784f6f8cec728df655e5f7d26a9',
      1 => 
      array (
        0 => 'dateexception',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\symfony\\polyfill-php83\\Resources\\stubs\\DateInvalidOperationException.php' => 
    array (
      0 => 'c514a879a3544566510c2c0a91b1b1a082f1e59e',
      1 => 
      array (
        0 => 'dateinvalidoperationexception',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\symfony\\polyfill-php83\\Resources\\stubs\\DateInvalidTimeZoneException.php' => 
    array (
      0 => '9dd3725abd945fff1eecdccda915e4fe5e13f4fe',
      1 => 
      array (
        0 => 'dateinvalidtimezoneexception',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\symfony\\polyfill-php83\\Resources\\stubs\\DateMalformedIntervalStringException.php' => 
    array (
      0 => 'dbd4ce64cc4cb83a81cacb01dc9a7e2e02beaea5',
      1 => 
      array (
        0 => 'datemalformedintervalstringexception',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\symfony\\polyfill-php83\\Resources\\stubs\\DateMalformedPeriodStringException.php' => 
    array (
      0 => 'c8a6e7796fbec0c3b1a6db401a897ddc128f133b',
      1 => 
      array (
        0 => 'datemalformedperiodstringexception',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\symfony\\polyfill-php83\\Resources\\stubs\\DateMalformedStringException.php' => 
    array (
      0 => '5a2b12bd3f5b10658acf4d9f0c8c9581218a099a',
      1 => 
      array (
        0 => 'datemalformedstringexception',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\symfony\\polyfill-php83\\Resources\\stubs\\DateObjectError.php' => 
    array (
      0 => '5ecda63e0c1a1d420422a90b060c5b9a82b3b856',
      1 => 
      array (
        0 => 'dateobjecterror',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\symfony\\polyfill-php83\\Resources\\stubs\\DateRangeError.php' => 
    array (
      0 => '95434544bd2764aa084667729cc6a9c5b10db9e3',
      1 => 
      array (
        0 => 'daterangeerror',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\symfony\\polyfill-php83\\Resources\\stubs\\Override.php' => 
    array (
      0 => 'ea5a9d50cfb4d187336cf7aecac4ba7268777a20',
      1 => 
      array (
        0 => 'override',
      ),
      2 => 
      array (
        0 => '__construct',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\symfony\\polyfill-php83\\Resources\\stubs\\SQLite3Exception.php' => 
    array (
      0 => '1bb73b922ce93a9ac9fe50baccccf014c0a47a15',
      1 => 
      array (
        0 => 'sqlite3exception',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
  ),
));