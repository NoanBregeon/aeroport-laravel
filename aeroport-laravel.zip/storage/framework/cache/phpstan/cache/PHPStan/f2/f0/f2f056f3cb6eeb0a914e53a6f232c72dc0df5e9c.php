<?php declare(strict_types = 1);

// odsl-C:/code/aeroport-laravel/vendor/composer/../phpunit/php-file-iterator/src/
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v1',
   'data' => 
  array (
    'C:\\code\\aeroport-laravel\\vendor\\phpunit\\php-file-iterator\\src\\ExcludeIterator.php' => 
    array (
      0 => 'bbc6dea49a445f0aebb485d20ab9a8a6626a9b72',
      1 => 
      array (
        0 => 'sebastianbergmann\\fileiterator\\excludeiterator',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\fileiterator\\__construct',
        1 => 'sebastianbergmann\\fileiterator\\accept',
        2 => 'sebastianbergmann\\fileiterator\\haschildren',
        3 => 'sebastianbergmann\\fileiterator\\getchildren',
        4 => 'sebastianbergmann\\fileiterator\\getinneriterator',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\phpunit\\php-file-iterator\\src\\Facade.php' => 
    array (
      0 => 'f803b327d5045ca3f9fc605e30f734ca1e8a0c76',
      1 => 
      array (
        0 => 'sebastianbergmann\\fileiterator\\facade',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\fileiterator\\getfilesasarray',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\phpunit\\php-file-iterator\\src\\Factory.php' => 
    array (
      0 => 'e69d15c6d5f465604fad3df75be7607ddcf9543b',
      1 => 
      array (
        0 => 'sebastianbergmann\\fileiterator\\factory',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\fileiterator\\getfileiterator',
        1 => 'sebastianbergmann\\fileiterator\\resolvewildcards',
        2 => 'sebastianbergmann\\fileiterator\\globstar',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\phpunit\\php-file-iterator\\src\\Iterator.php' => 
    array (
      0 => '678ba73fbeb1648ef0ec82e55c8e273889a8bd91',
      1 => 
      array (
        0 => 'sebastianbergmann\\fileiterator\\iterator',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\fileiterator\\__construct',
        1 => 'sebastianbergmann\\fileiterator\\accept',
        2 => 'sebastianbergmann\\fileiterator\\acceptpath',
        3 => 'sebastianbergmann\\fileiterator\\acceptprefix',
        4 => 'sebastianbergmann\\fileiterator\\acceptsuffix',
        5 => 'sebastianbergmann\\fileiterator\\acceptsubstring',
      ),
      3 => 
      array (
      ),
    ),
  ),
));