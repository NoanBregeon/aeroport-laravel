<?php declare(strict_types = 1);

// odsl-C:/code/aeroport-laravel/vendor/composer/../symfony/polyfill-php80/Resources/stubs
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v1',
   'data' => 
  array (
    'C:\\code\\aeroport-laravel\\vendor\\symfony\\polyfill-php80\\Resources\\stubs\\Attribute.php' => 
    array (
      0 => '47c6abc4ac611a90c5b2467dcb2ea538e007ba86',
      1 => 
      array (
        0 => 'attribute',
      ),
      2 => 
      array (
        0 => '__construct',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\symfony\\polyfill-php80\\Resources\\stubs\\PhpToken.php' => 
    array (
      0 => 'e0e4bac5c82637b71bfdf01c897435f71d41cd02',
      1 => 
      array (
        0 => 'phptoken',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\symfony\\polyfill-php80\\Resources\\stubs\\Stringable.php' => 
    array (
      0 => 'e357f36e99e71a1ac08785024dd6fda3c0b6e50a',
      1 => 
      array (
        0 => 'stringable',
      ),
      2 => 
      array (
        0 => '__tostring',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\symfony\\polyfill-php80\\Resources\\stubs\\UnhandledMatchError.php' => 
    array (
      0 => '84ba3b5c3e0a192c71d9dabad016b25f87206100',
      1 => 
      array (
        0 => 'unhandledmatcherror',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\symfony\\polyfill-php80\\Resources\\stubs\\ValueError.php' => 
    array (
      0 => 'fed6a92720e1d9b3692ac59205e682bcb8648c27',
      1 => 
      array (
        0 => 'valueerror',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
  ),
));