<?php declare(strict_types = 1);

// odsl-C:/code/aeroport-laravel/vendor/composer/../php-parallel-lint/php-parallel-lint/./src/
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v1',
   'data' => 
  array (
    'C:\\code\\aeroport-laravel\\vendor\\php-parallel-lint\\php-parallel-lint\\src\\Application.php' => 
    array (
      0 => '505fa6a137cf8b74f4c6b738416464ebd3a29aa7',
      1 => 
      array (
        0 => 'jakubonderka\\phpparallellint\\application',
      ),
      2 => 
      array (
        0 => 'jakubonderka\\phpparallellint\\run',
        1 => 'jakubonderka\\phpparallellint\\showoptions',
        2 => 'jakubonderka\\phpparallellint\\showversion',
        3 => 'jakubonderka\\phpparallellint\\showusage',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\php-parallel-lint\\php-parallel-lint\\src\\Contracts\\SyntaxErrorCallback.php' => 
    array (
      0 => '030ae502e487b44c8943787da53e72e965e9f8a4',
      1 => 
      array (
        0 => 'jakubonderka\\phpparallellint\\contracts\\syntaxerrorcallback',
      ),
      2 => 
      array (
        0 => 'jakubonderka\\phpparallellint\\contracts\\errorfound',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\php-parallel-lint\\php-parallel-lint\\src\\Error.php' => 
    array (
      0 => '48ce2c54b78bfcdf82760f220da5793f97b94af8',
      1 => 
      array (
        0 => 'jakubonderka\\phpparallellint\\error',
        1 => 'jakubonderka\\phpparallellint\\blame',
        2 => 'jakubonderka\\phpparallellint\\syntaxerror',
      ),
      2 => 
      array (
        0 => 'jakubonderka\\phpparallellint\\__construct',
        1 => 'jakubonderka\\phpparallellint\\getmessage',
        2 => 'jakubonderka\\phpparallellint\\getfilepath',
        3 => 'jakubonderka\\phpparallellint\\getshortfilepath',
        4 => 'jakubonderka\\phpparallellint\\jsonserialize',
        5 => 'jakubonderka\\phpparallellint\\jsonserialize',
        6 => 'jakubonderka\\phpparallellint\\getline',
        7 => 'jakubonderka\\phpparallellint\\getnormalizedmessage',
        8 => 'jakubonderka\\phpparallellint\\setblame',
        9 => 'jakubonderka\\phpparallellint\\getblame',
        10 => 'jakubonderka\\phpparallellint\\translatetokens',
        11 => 'jakubonderka\\phpparallellint\\jsonserialize',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\php-parallel-lint\\php-parallel-lint\\src\\ErrorFormatter.php' => 
    array (
      0 => 'f0b40d60fcf3fb863c31fea498428273d8f2eaab',
      1 => 
      array (
        0 => 'jakubonderka\\phpparallellint\\errorformatter',
      ),
      2 => 
      array (
        0 => 'jakubonderka\\phpparallellint\\__construct',
        1 => 'jakubonderka\\phpparallellint\\format',
        2 => 'jakubonderka\\phpparallellint\\formatsyntaxerrormessage',
        3 => 'jakubonderka\\phpparallellint\\getcodesnippet',
        4 => 'jakubonderka\\phpparallellint\\getcoloredcodesnippet',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\php-parallel-lint\\php-parallel-lint\\src\\exceptions.php' => 
    array (
      0 => '25a01ed8b22afc9c385d21378fc3a15a95423415',
      1 => 
      array (
        0 => 'jakubonderka\\phpparallellint\\exception',
        1 => 'jakubonderka\\phpparallellint\\runtimeexception',
        2 => 'jakubonderka\\phpparallellint\\invalidargumentexception',
        3 => 'jakubonderka\\phpparallellint\\notexistspathexception',
        4 => 'jakubonderka\\phpparallellint\\notexistsclassexception',
        5 => 'jakubonderka\\phpparallellint\\notimplementcallbackexception',
      ),
      2 => 
      array (
        0 => 'jakubonderka\\phpparallellint\\jsonserialize',
        1 => 'jakubonderka\\phpparallellint\\__construct',
        2 => 'jakubonderka\\phpparallellint\\getargument',
        3 => 'jakubonderka\\phpparallellint\\__construct',
        4 => 'jakubonderka\\phpparallellint\\getpath',
        5 => 'jakubonderka\\phpparallellint\\__construct',
        6 => 'jakubonderka\\phpparallellint\\getclassname',
        7 => 'jakubonderka\\phpparallellint\\getfilename',
        8 => 'jakubonderka\\phpparallellint\\__construct',
        9 => 'jakubonderka\\phpparallellint\\getclassname',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\php-parallel-lint\\php-parallel-lint\\src\\Manager.php' => 
    array (
      0 => '97b578cdbff9abfe70b8fe485326a927cb6660ec',
      1 => 
      array (
        0 => 'jakubonderka\\phpparallellint\\manager',
        1 => 'jakubonderka\\phpparallellint\\recursivedirectoryfilteriterator',
      ),
      2 => 
      array (
        0 => 'jakubonderka\\phpparallellint\\run',
        1 => 'jakubonderka\\phpparallellint\\setoutput',
        2 => 'jakubonderka\\phpparallellint\\getdefaultoutput',
        3 => 'jakubonderka\\phpparallellint\\gitblame',
        4 => 'jakubonderka\\phpparallellint\\getfilesfrompaths',
        5 => 'jakubonderka\\phpparallellint\\createsyntaxerrorcallback',
        6 => 'jakubonderka\\phpparallellint\\__construct',
        7 => 'jakubonderka\\phpparallellint\\accept',
        8 => 'jakubonderka\\phpparallellint\\haschildren',
        9 => 'jakubonderka\\phpparallellint\\getchildren',
        10 => 'jakubonderka\\phpparallellint\\getpathname',
        11 => 'jakubonderka\\phpparallellint\\normalizedirectoryseparator',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\php-parallel-lint\\php-parallel-lint\\src\\Output.php' => 
    array (
      0 => 'de21ec8592037f1fc47a60145f3385820d8fc02d',
      1 => 
      array (
        0 => 'jakubonderka\\phpparallellint\\output',
        1 => 'jakubonderka\\phpparallellint\\jsonoutput',
        2 => 'jakubonderka\\phpparallellint\\gitlaboutput',
        3 => 'jakubonderka\\phpparallellint\\textoutput',
        4 => 'jakubonderka\\phpparallellint\\checkstyleoutput',
        5 => 'jakubonderka\\phpparallellint\\textoutputcolored',
        6 => 'jakubonderka\\phpparallellint\\iwriter',
        7 => 'jakubonderka\\phpparallellint\\nullwriter',
        8 => 'jakubonderka\\phpparallellint\\consolewriter',
        9 => 'jakubonderka\\phpparallellint\\filewriter',
        10 => 'jakubonderka\\phpparallellint\\multiplewriter',
      ),
      2 => 
      array (
        0 => 'jakubonderka\\phpparallellint\\__construct',
        1 => 'jakubonderka\\phpparallellint\\ok',
        2 => 'jakubonderka\\phpparallellint\\skip',
        3 => 'jakubonderka\\phpparallellint\\error',
        4 => 'jakubonderka\\phpparallellint\\fail',
        5 => 'jakubonderka\\phpparallellint\\settotalfilecount',
        6 => 'jakubonderka\\phpparallellint\\writeheader',
        7 => 'jakubonderka\\phpparallellint\\writeresult',
        8 => 'jakubonderka\\phpparallellint\\__construct',
        9 => 'jakubonderka\\phpparallellint\\ok',
        10 => 'jakubonderka\\phpparallellint\\skip',
        11 => 'jakubonderka\\phpparallellint\\error',
        12 => 'jakubonderka\\phpparallellint\\fail',
        13 => 'jakubonderka\\phpparallellint\\settotalfilecount',
        14 => 'jakubonderka\\phpparallellint\\writeheader',
        15 => 'jakubonderka\\phpparallellint\\writeresult',
        16 => 'jakubonderka\\phpparallellint\\__construct',
        17 => 'jakubonderka\\phpparallellint\\ok',
        18 => 'jakubonderka\\phpparallellint\\skip',
        19 => 'jakubonderka\\phpparallellint\\error',
        20 => 'jakubonderka\\phpparallellint\\fail',
        21 => 'jakubonderka\\phpparallellint\\settotalfilecount',
        22 => 'jakubonderka\\phpparallellint\\writeheader',
        23 => 'jakubonderka\\phpparallellint\\writeresult',
        24 => 'jakubonderka\\phpparallellint\\__construct',
        25 => 'jakubonderka\\phpparallellint\\ok',
        26 => 'jakubonderka\\phpparallellint\\skip',
        27 => 'jakubonderka\\phpparallellint\\error',
        28 => 'jakubonderka\\phpparallellint\\fail',
        29 => 'jakubonderka\\phpparallellint\\write',
        30 => 'jakubonderka\\phpparallellint\\writeline',
        31 => 'jakubonderka\\phpparallellint\\writenewline',
        32 => 'jakubonderka\\phpparallellint\\settotalfilecount',
        33 => 'jakubonderka\\phpparallellint\\writeheader',
        34 => 'jakubonderka\\phpparallellint\\writeresult',
        35 => 'jakubonderka\\phpparallellint\\writemark',
        36 => 'jakubonderka\\phpparallellint\\writepercent',
        37 => 'jakubonderka\\phpparallellint\\stringwidth',
        38 => 'jakubonderka\\phpparallellint\\phpversionidtostring',
        39 => 'jakubonderka\\phpparallellint\\__construct',
        40 => 'jakubonderka\\phpparallellint\\ok',
        41 => 'jakubonderka\\phpparallellint\\skip',
        42 => 'jakubonderka\\phpparallellint\\error',
        43 => 'jakubonderka\\phpparallellint\\fail',
        44 => 'jakubonderka\\phpparallellint\\settotalfilecount',
        45 => 'jakubonderka\\phpparallellint\\writeheader',
        46 => 'jakubonderka\\phpparallellint\\writeresult',
        47 => 'jakubonderka\\phpparallellint\\__construct',
        48 => 'jakubonderka\\phpparallellint\\write',
        49 => 'jakubonderka\\phpparallellint\\write',
        50 => 'jakubonderka\\phpparallellint\\write',
        51 => 'jakubonderka\\phpparallellint\\write',
        52 => 'jakubonderka\\phpparallellint\\__construct',
        53 => 'jakubonderka\\phpparallellint\\write',
        54 => 'jakubonderka\\phpparallellint\\__destruct',
        55 => 'jakubonderka\\phpparallellint\\__construct',
        56 => 'jakubonderka\\phpparallellint\\addwriter',
        57 => 'jakubonderka\\phpparallellint\\write',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\php-parallel-lint\\php-parallel-lint\\src\\ParallelLint.php' => 
    array (
      0 => '926ac05ecf25de24ef9faf17e4adab60399c96b2',
      1 => 
      array (
        0 => 'jakubonderka\\phpparallellint\\parallellint',
      ),
      2 => 
      array (
        0 => 'jakubonderka\\phpparallellint\\__construct',
        1 => 'jakubonderka\\phpparallellint\\lint',
        2 => 'jakubonderka\\phpparallellint\\getparalleljobs',
        3 => 'jakubonderka\\phpparallellint\\setparalleljobs',
        4 => 'jakubonderka\\phpparallellint\\getphpexecutable',
        5 => 'jakubonderka\\phpparallellint\\setphpexecutable',
        6 => 'jakubonderka\\phpparallellint\\getprocesscallback',
        7 => 'jakubonderka\\phpparallellint\\setprocesscallback',
        8 => 'jakubonderka\\phpparallellint\\isasptagsenabled',
        9 => 'jakubonderka\\phpparallellint\\setasptagsenabled',
        10 => 'jakubonderka\\phpparallellint\\isshorttagenabled',
        11 => 'jakubonderka\\phpparallellint\\setshorttagenabled',
        12 => 'jakubonderka\\phpparallellint\\isshowdeprecated',
        13 => 'jakubonderka\\phpparallellint\\setshowdeprecated',
        14 => 'jakubonderka\\phpparallellint\\triggersyntaxerrorcallback',
        15 => 'jakubonderka\\phpparallellint\\setsyntaxerrorcallback',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\php-parallel-lint\\php-parallel-lint\\src\\polyfill.php' => 
    array (
      0 => 'f92592f5a58e6c089b753e50526079e0c8baa4b2',
      1 => 
      array (
        0 => 'jsonserializable',
      ),
      2 => 
      array (
        0 => 'jsonserialize',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\php-parallel-lint\\php-parallel-lint\\src\\Process\\GitBlameProcess.php' => 
    array (
      0 => '3738716d6c8f9a2f60dd774671f329d4949029e0',
      1 => 
      array (
        0 => 'jakubonderka\\phpparallellint\\process\\gitblameprocess',
      ),
      2 => 
      array (
        0 => 'jakubonderka\\phpparallellint\\process\\__construct',
        1 => 'jakubonderka\\phpparallellint\\process\\issuccess',
        2 => 'jakubonderka\\phpparallellint\\process\\getauthor',
        3 => 'jakubonderka\\phpparallellint\\process\\getauthoremail',
        4 => 'jakubonderka\\phpparallellint\\process\\getauthortime',
        5 => 'jakubonderka\\phpparallellint\\process\\getcommithash',
        6 => 'jakubonderka\\phpparallellint\\process\\getsummary',
        7 => 'jakubonderka\\phpparallellint\\process\\gitexists',
        8 => 'jakubonderka\\phpparallellint\\process\\getdatetime',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\php-parallel-lint\\php-parallel-lint\\src\\Process\\LintProcess.php' => 
    array (
      0 => 'd739a2db27350f1e3ad14ca0b5a57d245d7bf6b1',
      1 => 
      array (
        0 => 'jakubonderka\\phpparallellint\\process\\lintprocess',
      ),
      2 => 
      array (
        0 => 'jakubonderka\\phpparallellint\\process\\__construct',
        1 => 'jakubonderka\\phpparallellint\\process\\containserror',
        2 => 'jakubonderka\\phpparallellint\\process\\getsyntaxerror',
        3 => 'jakubonderka\\phpparallellint\\process\\isfail',
        4 => 'jakubonderka\\phpparallellint\\process\\issuccess',
        5 => 'jakubonderka\\phpparallellint\\process\\containsparsererror',
        6 => 'jakubonderka\\phpparallellint\\process\\containsfatalerror',
        7 => 'jakubonderka\\phpparallellint\\process\\containsdeprecatederror',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\php-parallel-lint\\php-parallel-lint\\src\\Process\\PhpExecutable.php' => 
    array (
      0 => 'bf24d7b1b595aac2588572230ce4d58f09e61b7a',
      1 => 
      array (
        0 => 'jakubonderka\\phpparallellint\\process\\phpexecutable',
      ),
      2 => 
      array (
        0 => 'jakubonderka\\phpparallellint\\process\\__construct',
        1 => 'jakubonderka\\phpparallellint\\process\\gethhvmversion',
        2 => 'jakubonderka\\phpparallellint\\process\\isishhvmtype',
        3 => 'jakubonderka\\phpparallellint\\process\\getpath',
        4 => 'jakubonderka\\phpparallellint\\process\\getversionid',
        5 => 'jakubonderka\\phpparallellint\\process\\getphpexecutable',
        6 => 'jakubonderka\\phpparallellint\\process\\getphpexecutablefromoutput',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\php-parallel-lint\\php-parallel-lint\\src\\Process\\PhpProcess.php' => 
    array (
      0 => '7963a6bafe8115853ef282e084f8fb36f1f96129',
      1 => 
      array (
        0 => 'jakubonderka\\phpparallellint\\process\\phpprocess',
      ),
      2 => 
      array (
        0 => 'jakubonderka\\phpparallellint\\process\\__construct',
        1 => 'jakubonderka\\phpparallellint\\process\\constructparameters',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\php-parallel-lint\\php-parallel-lint\\src\\Process\\Process.php' => 
    array (
      0 => 'e5e16fed1a4e17ae8337746a5dc5cf87094c4a1a',
      1 => 
      array (
        0 => 'jakubonderka\\phpparallellint\\process\\process',
      ),
      2 => 
      array (
        0 => 'jakubonderka\\phpparallellint\\process\\__construct',
        1 => 'jakubonderka\\phpparallellint\\process\\isfinished',
        2 => 'jakubonderka\\phpparallellint\\process\\waitforfinish',
        3 => 'jakubonderka\\phpparallellint\\process\\getoutput',
        4 => 'jakubonderka\\phpparallellint\\process\\geterroroutput',
        5 => 'jakubonderka\\phpparallellint\\process\\getstatuscode',
        6 => 'jakubonderka\\phpparallellint\\process\\isfail',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\php-parallel-lint\\php-parallel-lint\\src\\Process\\SkipLintProcess.php' => 
    array (
      0 => 'd47d1a183a41b0ebce3e3039a25b44a959462f24',
      1 => 
      array (
        0 => 'jakubonderka\\phpparallellint\\process\\skiplintprocess',
      ),
      2 => 
      array (
        0 => 'jakubonderka\\phpparallellint\\process\\__construct',
        1 => 'jakubonderka\\phpparallellint\\process\\getchunk',
        2 => 'jakubonderka\\phpparallellint\\process\\isfinished',
        3 => 'jakubonderka\\phpparallellint\\process\\isskipped',
        4 => 'jakubonderka\\phpparallellint\\process\\processlines',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\php-parallel-lint\\php-parallel-lint\\src\\Result.php' => 
    array (
      0 => '16c3c51c4eb630c8683d1faaf6a219871a93f45d',
      1 => 
      array (
        0 => 'jakubonderka\\phpparallellint\\result',
      ),
      2 => 
      array (
        0 => 'jakubonderka\\phpparallellint\\__construct',
        1 => 'jakubonderka\\phpparallellint\\geterrors',
        2 => 'jakubonderka\\phpparallellint\\haserror',
        3 => 'jakubonderka\\phpparallellint\\getfileswithfail',
        4 => 'jakubonderka\\phpparallellint\\getfileswithfailcount',
        5 => 'jakubonderka\\phpparallellint\\hasfileswithfail',
        6 => 'jakubonderka\\phpparallellint\\getcheckedfiles',
        7 => 'jakubonderka\\phpparallellint\\getcheckedfilescount',
        8 => 'jakubonderka\\phpparallellint\\getskippedfiles',
        9 => 'jakubonderka\\phpparallellint\\getskippedfilescount',
        10 => 'jakubonderka\\phpparallellint\\getfileswithsyntaxerror',
        11 => 'jakubonderka\\phpparallellint\\getfileswithsyntaxerrorcount',
        12 => 'jakubonderka\\phpparallellint\\hassyntaxerror',
        13 => 'jakubonderka\\phpparallellint\\gettesttime',
        14 => 'jakubonderka\\phpparallellint\\jsonserialize',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\php-parallel-lint\\php-parallel-lint\\src\\Settings.php' => 
    array (
      0 => '646bbea5e92da694ed04d0a0e171aa6198cd1325',
      1 => 
      array (
        0 => 'jakubonderka\\phpparallellint\\settings',
        1 => 'jakubonderka\\phpparallellint\\arrayiterator',
      ),
      2 => 
      array (
        0 => 'jakubonderka\\phpparallellint\\addpaths',
        1 => 'jakubonderka\\phpparallellint\\parsearguments',
        2 => 'jakubonderka\\phpparallellint\\getpathsfromstdin',
        3 => 'jakubonderka\\phpparallellint\\getnext',
      ),
      3 => 
      array (
      ),
    ),
  ),
));