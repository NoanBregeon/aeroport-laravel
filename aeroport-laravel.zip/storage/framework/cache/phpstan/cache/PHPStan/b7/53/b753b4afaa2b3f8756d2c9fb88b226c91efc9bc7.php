<?php declare(strict_types = 1);

// odsl-C:/code/aeroport-laravel/vendor/composer/../phar-io/version/src/
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v1',
   'data' => 
  array (
    'C:\\code\\aeroport-laravel\\vendor\\phar-io\\version\\src\\BuildMetaData.php' => 
    array (
      0 => '95ad9aaa6c32718b2f6eef38225240b35b1f0dd2',
      1 => 
      array (
        0 => 'phario\\version\\buildmetadata',
      ),
      2 => 
      array (
        0 => 'phario\\version\\__construct',
        1 => 'phario\\version\\asstring',
        2 => 'phario\\version\\equals',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\phar-io\\version\\src\\constraints\\AbstractVersionConstraint.php' => 
    array (
      0 => 'fb4e0fb4a4e89c491e9bd47da3f4bcf5e65c84c0',
      1 => 
      array (
        0 => 'phario\\version\\abstractversionconstraint',
      ),
      2 => 
      array (
        0 => 'phario\\version\\__construct',
        1 => 'phario\\version\\asstring',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\phar-io\\version\\src\\constraints\\AndVersionConstraintGroup.php' => 
    array (
      0 => 'cfd803b2ea9d969e10383a2748a56dced4b73cce',
      1 => 
      array (
        0 => 'phario\\version\\andversionconstraintgroup',
      ),
      2 => 
      array (
        0 => 'phario\\version\\__construct',
        1 => 'phario\\version\\complies',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\phar-io\\version\\src\\constraints\\AnyVersionConstraint.php' => 
    array (
      0 => '7b6997dda7e61a5a3e47f96b2ac20026a4ad1d51',
      1 => 
      array (
        0 => 'phario\\version\\anyversionconstraint',
      ),
      2 => 
      array (
        0 => 'phario\\version\\complies',
        1 => 'phario\\version\\asstring',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\phar-io\\version\\src\\constraints\\ExactVersionConstraint.php' => 
    array (
      0 => '098c09d62983d3e6fd71485e87116115d4a80924',
      1 => 
      array (
        0 => 'phario\\version\\exactversionconstraint',
      ),
      2 => 
      array (
        0 => 'phario\\version\\complies',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\phar-io\\version\\src\\constraints\\GreaterThanOrEqualToVersionConstraint.php' => 
    array (
      0 => '31d8c4914a7c2f16bf36f538563ee412f856cdb3',
      1 => 
      array (
        0 => 'phario\\version\\greaterthanorequaltoversionconstraint',
      ),
      2 => 
      array (
        0 => 'phario\\version\\__construct',
        1 => 'phario\\version\\complies',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\phar-io\\version\\src\\constraints\\OrVersionConstraintGroup.php' => 
    array (
      0 => '004772604023115b3ef7c28ec4fb7d3301dc4dca',
      1 => 
      array (
        0 => 'phario\\version\\orversionconstraintgroup',
      ),
      2 => 
      array (
        0 => 'phario\\version\\__construct',
        1 => 'phario\\version\\complies',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\phar-io\\version\\src\\constraints\\SpecificMajorAndMinorVersionConstraint.php' => 
    array (
      0 => '8c0b72e8a6fcb8f48e20e49abf6d8103d987b1a5',
      1 => 
      array (
        0 => 'phario\\version\\specificmajorandminorversionconstraint',
      ),
      2 => 
      array (
        0 => 'phario\\version\\__construct',
        1 => 'phario\\version\\complies',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\phar-io\\version\\src\\constraints\\SpecificMajorVersionConstraint.php' => 
    array (
      0 => 'efb81e3e5493d3908a9c3d51ad16e0329f5fbc68',
      1 => 
      array (
        0 => 'phario\\version\\specificmajorversionconstraint',
      ),
      2 => 
      array (
        0 => 'phario\\version\\__construct',
        1 => 'phario\\version\\complies',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\phar-io\\version\\src\\constraints\\VersionConstraint.php' => 
    array (
      0 => '495be7eb8e0d23c2829f3418b2551feb54b268e9',
      1 => 
      array (
        0 => 'phario\\version\\versionconstraint',
      ),
      2 => 
      array (
        0 => 'phario\\version\\complies',
        1 => 'phario\\version\\asstring',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\phar-io\\version\\src\\exceptions\\Exception.php' => 
    array (
      0 => '80bf09b2245e8a57b9fa84102198062b05d28491',
      1 => 
      array (
        0 => 'phario\\version\\exception',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\phar-io\\version\\src\\exceptions\\InvalidPreReleaseSuffixException.php' => 
    array (
      0 => 'd295ffaf424bd318b52ca58a22e134a757adc551',
      1 => 
      array (
        0 => 'phario\\version\\invalidprereleasesuffixexception',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\phar-io\\version\\src\\exceptions\\InvalidVersionException.php' => 
    array (
      0 => 'b5af6590c57b8aab0245a2c491f96c4614225664',
      1 => 
      array (
        0 => 'phario\\version\\invalidversionexception',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\phar-io\\version\\src\\exceptions\\NoBuildMetaDataException.php' => 
    array (
      0 => '2fbcf83ac53911226fefa01823ebc6b6cd7e2e41',
      1 => 
      array (
        0 => 'phario\\version\\nobuildmetadataexception',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\phar-io\\version\\src\\exceptions\\NoPreReleaseSuffixException.php' => 
    array (
      0 => '30b1fabe90aa1cc2841f4d05e8b40a46679ba879',
      1 => 
      array (
        0 => 'phario\\version\\noprereleasesuffixexception',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\phar-io\\version\\src\\exceptions\\UnsupportedVersionConstraintException.php' => 
    array (
      0 => '8ba115bff96f1628f72295ac082b41ae9d2da288',
      1 => 
      array (
        0 => 'phario\\version\\unsupportedversionconstraintexception',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\phar-io\\version\\src\\PreReleaseSuffix.php' => 
    array (
      0 => 'bb71a0619caa8bbac829636ca159c5b36b9fb53c',
      1 => 
      array (
        0 => 'phario\\version\\prereleasesuffix',
      ),
      2 => 
      array (
        0 => 'phario\\version\\__construct',
        1 => 'phario\\version\\asstring',
        2 => 'phario\\version\\getvalue',
        3 => 'phario\\version\\getnumber',
        4 => 'phario\\version\\isgreaterthan',
        5 => 'phario\\version\\mapvaluetoscore',
        6 => 'phario\\version\\parsevalue',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\phar-io\\version\\src\\Version.php' => 
    array (
      0 => 'b9cafee10b996648c21658a7f93de53410158b42',
      1 => 
      array (
        0 => 'phario\\version\\version',
      ),
      2 => 
      array (
        0 => 'phario\\version\\__construct',
        1 => 'phario\\version\\getprereleasesuffix',
        2 => 'phario\\version\\getoriginalstring',
        3 => 'phario\\version\\getversionstring',
        4 => 'phario\\version\\hasprereleasesuffix',
        5 => 'phario\\version\\equals',
        6 => 'phario\\version\\isgreaterthan',
        7 => 'phario\\version\\getmajor',
        8 => 'phario\\version\\getminor',
        9 => 'phario\\version\\getpatch',
        10 => 'phario\\version\\hasbuildmetadata',
        11 => 'phario\\version\\getbuildmetadata',
        12 => 'phario\\version\\parseversion',
        13 => 'phario\\version\\ensureversionstringisvalid',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\phar-io\\version\\src\\VersionConstraintParser.php' => 
    array (
      0 => '9a03d1fcfe10968b84fafa941ca1710997e79341',
      1 => 
      array (
        0 => 'phario\\version\\versionconstraintparser',
      ),
      2 => 
      array (
        0 => 'phario\\version\\parse',
        1 => 'phario\\version\\handleorgroup',
        2 => 'phario\\version\\handletildeoperator',
        3 => 'phario\\version\\handlecaretoperator',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\phar-io\\version\\src\\VersionConstraintValue.php' => 
    array (
      0 => '9cf0c4f77d86b54c45d730a708ce9dbcb1a53ae8',
      1 => 
      array (
        0 => 'phario\\version\\versionconstraintvalue',
      ),
      2 => 
      array (
        0 => 'phario\\version\\__construct',
        1 => 'phario\\version\\getlabel',
        2 => 'phario\\version\\getbuildmetadata',
        3 => 'phario\\version\\getversionstring',
        4 => 'phario\\version\\getmajor',
        5 => 'phario\\version\\getminor',
        6 => 'phario\\version\\getpatch',
        7 => 'phario\\version\\parseversion',
        8 => 'phario\\version\\extractbuildmetadata',
        9 => 'phario\\version\\extractlabel',
        10 => 'phario\\version\\strippotentialvprefix',
      ),
      3 => 
      array (
      ),
    ),
    'C:\\code\\aeroport-laravel\\vendor\\phar-io\\version\\src\\VersionNumber.php' => 
    array (
      0 => 'ec8c13c18e185e2163ec31423a3c0c6d05f89bca',
      1 => 
      array (
        0 => 'phario\\version\\versionnumber',
      ),
      2 => 
      array (
        0 => 'phario\\version\\__construct',
        1 => 'phario\\version\\isany',
        2 => 'phario\\version\\getvalue',
      ),
      3 => 
      array (
      ),
    ),
  ),
));