<?php declare(strict_types = 1);

// odsl-C:/code/aeroport-laravel/vendor/composer/../sebastian/exporter/src/
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v1',
   'data' => 
  array (
    'C:\\code\\aeroport-laravel\\vendor\\sebastian\\exporter\\src\\Exporter.php' => 
    array (
      0 => '36f24a5ce47cfa4bb11c23a5921b79b0ba752001',
      1 => 
      array (
        0 => 'sebastianbergmann\\exporter\\exporter',
      ),
      2 => 
      array (
        0 => 'sebastianbergmann\\exporter\\__construct',
        1 => 'sebastianbergmann\\exporter\\export',
        2 => 'sebastianbergmann\\exporter\\shortenedrecursiveexport',
        3 => 'sebastianbergmann\\exporter\\shortenedexport',
        4 => 'sebastianbergmann\\exporter\\toarray',
        5 => 'sebastianbergmann\\exporter\\countproperties',
        6 => 'sebastianbergmann\\exporter\\shortenedcountedrecursiveexport',
        7 => 'sebastianbergmann\\exporter\\recursiveexport',
        8 => 'sebastianbergmann\\exporter\\exportfloat',
        9 => 'sebastianbergmann\\exporter\\exportstring',
        10 => 'sebastianbergmann\\exporter\\exportarray',
        11 => 'sebastianbergmann\\exporter\\exportobject',
        12 => 'sebastianbergmann\\exporter\\canbereflected',
      ),
      3 => 
      array (
      ),
    ),
  ),
));