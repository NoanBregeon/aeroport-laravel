<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container mx-auto py-6">
        <h1 class="text-2xl font-bold mb-4">Terminaux</h1>

        <?php if(session('status')): ?>
            <div class="bg-green-100 text-green-800 px-4 py-2 rounded mb-4">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>

        <div class="flex justify-between items-center mb-4">
            <p class="text-gray-700">
                Connecté en tant que <?php echo e(auth()->user()->name); ?>

            </p>

            <a href="<?php echo e(route('terminals.create')); ?>"
               class="bg-blue-600 text-white px-4 py-2 rounded">
                Nouveau terminal
            </a>
        </div>

        <table class="min-w-full bg-white border">
            <thead>
                <tr>
                    <th class="px-4 py-2 border">Nom</th>
                    <th class="px-4 py-2 border">Emplacement</th>
                    <th class="px-4 py-2 border">Mise en service</th>
                    <th class="px-4 py-2 border">Nb de halls</th>
                    <th class="px-4 py-2 border">Capacité portes ouvertes</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $terminals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $terminal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="px-4 py-2 border"><?php echo e($terminal->nom); ?></td>
                        <td class="px-4 py-2 border"><?php echo e($terminal->emplacement); ?></td>
                        <td class="px-4 py-2 border">
                            <?php echo e($terminal->date_mise_en_service?->format('d/m/Y')); ?>

                        </td>
                        <td class="px-4 py-2 border text-center">
                            <?php echo e($terminal->halls_count); ?>

                        </td>
                        <td class="px-4 py-2 border text-center">
                            <?php echo e($terminal->capacite_portes_ouvertes); ?>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="px-4 py-4 text-center text-gray-500">
                            Aucun terminal pour le moment.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\code\aeroport-laravel\resources\views/terminals/index.blade.php ENDPATH**/ ?>