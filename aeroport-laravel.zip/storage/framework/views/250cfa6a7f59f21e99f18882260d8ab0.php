<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Administration</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>

<body class="bg-gray-100">

    <div class="min-h-screen flex">

        <!-- SIDEBAR -->
        <aside class="w-64 bg-gray-900 text-gray-200 flex flex-col justify-between">

            <div>
                <!-- Title -->
                <div class="p-6 border-b border-gray-700">
                    <h2 class="text-2xl font-bold">Admin Panel</h2>
                </div>

                <!-- Navigation -->
                <nav class="p-4 space-y-2">
                    <a href="<?php echo e(route('admin.dashboard')); ?>" class="flex items-center px-4 py-2 rounded-lg hover:bg-gray-700 <?php echo e(request()->routeIs('admin.dashboard') ? 'bg-gray-800' : ''); ?>">🏠 <span class="ml-3">Dashboard</span></a>

                    <a href="<?php echo e(route('admin.terminals.index')); ?>" class="flex items-center px-4 py-2 rounded-lg hover:bg-gray-700 <?php echo e(request()->routeIs('admin.terminals.*') ? 'bg-gray-800' : ''); ?>">🏢 <span class="ml-3">Terminaux</span></a>

                    <a href="<?php echo e(route('admin.halls.index')); ?>" class="flex items-center px-4 py-2 rounded-lg hover:bg-gray-700 <?php echo e(request()->routeIs('admin.halls.*') ? 'bg-gray-800' : ''); ?>">🛫 <span class="ml-3">Halls</span></a>

                    <a href="<?php echo e(route('admin.gates.index')); ?>" class="flex items-center px-4 py-2 rounded-lg hover:bg-gray-700 <?php echo e(request()->routeIs('admin.gates.*') ? 'bg-gray-800' : ''); ?>">🚪 <span class="ml-3">Gates</span></a>
                </nav>
            </div>

            <!-- USER MENU -->
            <div class="p-4 border-t border-gray-800">
    <p class="text-sm text-gray-400 mb-2">Connecté :</p>
    <p class="font-semibold text-white mb-4"><?php echo e(auth()->user()->name); ?></p>

    <div class="space-y-3">

        <!-- Paramètres / Profil -->
        <a href="<?php echo e(route('profile.edit')); ?>"
            class="block px-4 py-2 rounded-lg bg-gray-800 hover:bg-gray-700">
            ⚙️ Paramètres du compte
        </a>

        <!-- Switch Langue -->
        <div class="flex space-x-2">

            <form action="<?php echo e(route('lang.switch')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="locale" value="fr">
                <button class="px-3 py-1 rounded-lg 
                    <?php echo e(app()->getLocale() === 'fr' ? 'bg-blue-600' : 'bg-gray-700'); ?> 
                    hover:bg-blue-500 transition">
                    🇫🇷 FR
                </button>
            </form>

            <form action="<?php echo e(route('lang.switch')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="locale" value="en">
                <button class="px-3 py-1 rounded-lg
                    <?php echo e(app()->getLocale() === 'en' ? 'bg-blue-600' : 'bg-gray-700'); ?>

                    hover:bg-blue-500 transition">
                    🇬🇧 EN
                </button>
            </form>

        </div>

        <!-- Déconnexion -->
        <form method="POST" action="<?php echo e(route('logout')); ?>">
            <?php echo csrf_field(); ?>
            <button class="w-full px-4 py-2 bg-red-600 hover:bg-red-500 text-white rounded-lg">
                🔓 Déconnexion
            </button>
        </form>

    </div>
</div>


        </aside>

        <!-- MAIN CONTENT -->
        <main class="flex-1 p-10">

            <h1 class="text-3xl font-bold mb-8">
                <?php echo $__env->yieldContent('title'); ?>
            </h1>

            <?php echo $__env->yieldContent('content'); ?>

        </main>
    </div>

</body>
</html>
<?php /**PATH C:\code\aeroport-laravel\resources\views/layouts/admin.blade.php ENDPATH**/ ?>