

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>

<div class="grid grid-cols-1 md:grid-cols-3 gap-6">

    <div class="p-6 bg-white shadow-lg rounded-xl border border-gray-200">
        <h2 class="text-xl font-semibold text-gray-700">Terminaux</h2>
        <p class="text-5xl font-bold text-blue-600 mt-3">
            <?php echo e($stats['terminaux']); ?>

        </p>
    </div>

    <div class="p-6 bg-white shadow-lg rounded-xl border border-gray-200">
        <h2 class="text-xl font-semibold text-gray-700">Halls</h2>
        <p class="text-5xl font-bold text-green-600 mt-3">
            <?php echo e($stats['halls']); ?>

        </p>
    </div>

    <div class="p-6 bg-white shadow-lg rounded-xl border border-gray-200">
        <h2 class="text-xl font-semibold text-gray-700">Gates</h2>
        <p class="text-5xl font-bold text-purple-600 mt-3">
            <?php echo e($stats['gates']); ?>

        </p>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\code\aeroport-laravel\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>