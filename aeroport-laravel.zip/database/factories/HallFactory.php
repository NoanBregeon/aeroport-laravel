<?php

namespace Database\Factories;

use App\Models\Hall;
use App\Models\Terminal;
use Illuminate\Database\Eloquent\Factories\Factory;

class HallFactory extends Factory
{
    protected $model = Hall::class;

    public function definition(): array
    {
        return [
            'terminal_id' => Terminal::factory(),
            'nom' => 'Hall A',
            'personnel_minimum' => 10,
        ];
    }
}
