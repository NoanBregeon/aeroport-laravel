<?php

namespace Database\Factories;

use App\Models\Terminal;
use Illuminate\Database\Eloquent\Factories\Factory;

class TerminalFactory extends Factory
{
    protected $model = Terminal::class;

    public function definition(): array
    {
        return [
            'nom' => 'Terminal 1',
            'emplacement' => 'Zone principale',
            'date_mise_en_service' => '2020-01-01',
        ];
    }
}
