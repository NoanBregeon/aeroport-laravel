<?php

namespace Database\Factories;

use App\Models\Gate;
use App\Models\Hall;
use Illuminate\Database\Eloquent\Factories\Factory;

class GateFactory extends Factory
{
    protected $model = Gate::class;

    public function definition(): array
    {
        return [
            'hall_id' => Hall::factory(),
            'nom' => 'Gate 1',
            'ouverte' => false,
            'capacite_max' => 100,
        ];
    }
}
